import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Brain, Home } from 'lucide-react';

const Navbar = () => {
  const location = useLocation();

  return (
    <nav className="bg-black/20 backdrop-blur-md border-b border-white/10 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2 text-white hover:text-blue-300 transition-colors">
            <Brain className="h-8 w-8" />
            <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              AI Pickr
            </span>
          </Link>
          
          {location.pathname !== '/' && (
            <Link 
              to="/" 
              className="flex items-center space-x-2 text-white/70 hover:text-white transition-colors"
            >
              <Home className="h-5 w-5" />
              <span>Home</span>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;