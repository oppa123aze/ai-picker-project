import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import MoviesPage from './pages/MoviesPage';
import FoodPage from './pages/FoodPage';
import ShoppingPage from './pages/ShoppingPage';
import RestaurantsPage from './pages/RestaurantsPage';
import ActivitiesPage from './pages/ActivitiesPage';
import MusicPage from './pages/MusicPage';
import BooksPage from './pages/BooksPage';
import GiftsPage from './pages/GiftsPage';
import TravelPage from './pages/TravelPage';
import Navbar from './components/Navbar';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/movies" element={<MoviesPage />} />
          <Route path="/food" element={<FoodPage />} />
          <Route path="/shopping" element={<ShoppingPage />} />
          <Route path="/restaurants" element={<RestaurantsPage />} />
          <Route path="/activities" element={<ActivitiesPage />} />
          <Route path="/music" element={<MusicPage />} />
          <Route path="/books" element={<BooksPage />} />
          <Route path="/gifts" element={<GiftsPage />} />
          <Route path="/travel" element={<TravelPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;