const SPOONACULAR_API_KEY = 'd7db7d161e4c410c9eb4ea4bb609c99f';
const SPOONACULAR_BASE_URL = 'https://api.spoonacular.com/recipes';
const MEALDB_BASE_URL = 'https://www.themealdb.com/api/json/v1/1';

export interface Recipe {
  id: number;
  title: string;
  image: string;
  readyInMinutes: number;
  servings: number;
  calories?: number;
  nutrition?: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  ingredients: string[];
  instructions: string;
  sourceUrl?: string;
  summary?: string;
}

export interface MealDBRecipe {
  idMeal: string;
  strMeal: string;
  strMealThumb: string;
  strInstructions: string;
  strCategory: string;
  strArea: string;
  ingredients: string[];
  measures: string[];
}

// Get recipes by ingredients using Spoonacular
export const getRecipesByIngredients = async (ingredients: string[]): Promise<Recipe[]> => {
  try {
    const ingredientString = ingredients.join(',');
    const response = await fetch(
      `${SPOONACULAR_BASE_URL}/findByIngredients?ingredients=${ingredientString}&number=10&apiKey=${SPOONACULAR_API_KEY}`
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch recipes');
    }
    
    const data = await response.json();
    
    // Get detailed information for each recipe
    const detailedRecipes = await Promise.all(
      data.slice(0, 5).map(async (recipe: any) => {
        const details = await getRecipeDetails(recipe.id);
        return details;
      })
    );
    
    return detailedRecipes.filter(recipe => recipe !== null);
  } catch (error) {
    console.error('Error fetching recipes by ingredients:', error);
    // Fallback to MealDB
    return await getRandomMealDBRecipes();
  }
};

// Get recipe details from Spoonacular
export const getRecipeDetails = async (id: number): Promise<Recipe | null> => {
  try {
    const response = await fetch(
      `${SPOONACULAR_BASE_URL}/${id}/information?includeNutrition=true&apiKey=${SPOONACULAR_API_KEY}`
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch recipe details');
    }
    
    const data = await response.json();
    
    return {
      id: data.id,
      title: data.title,
      image: data.image,
      readyInMinutes: data.readyInMinutes,
      servings: data.servings,
      calories: data.nutrition?.nutrients?.find((n: any) => n.name === 'Calories')?.amount,
      nutrition: {
        calories: data.nutrition?.nutrients?.find((n: any) => n.name === 'Calories')?.amount || 0,
        protein: data.nutrition?.nutrients?.find((n: any) => n.name === 'Protein')?.amount || 0,
        carbs: data.nutrition?.nutrients?.find((n: any) => n.name === 'Carbohydrates')?.amount || 0,
        fat: data.nutrition?.nutrients?.find((n: any) => n.name === 'Fat')?.amount || 0,
      },
      ingredients: data.extendedIngredients?.map((ing: any) => ing.original) || [],
      instructions: data.instructions || data.summary || '',
      sourceUrl: data.sourceUrl,
      summary: data.summary
    };
  } catch (error) {
    console.error('Error fetching recipe details:', error);
    return null;
  }
};

// Get random recipes from MealDB as fallback
export const getRandomMealDBRecipes = async (): Promise<Recipe[]> => {
  try {
    const recipes: Recipe[] = [];
    
    // Get 5 random meals
    for (let i = 0; i < 5; i++) {
      const response = await fetch(`${MEALDB_BASE_URL}/random.php`);
      const data = await response.json();
      
      if (data.meals && data.meals[0]) {
        const meal = data.meals[0];
        const ingredients = [];
        const measures = [];
        
        // Extract ingredients and measures
        for (let j = 1; j <= 20; j++) {
          const ingredient = meal[`strIngredient${j}`];
          const measure = meal[`strMeasure${j}`];
          if (ingredient && ingredient.trim()) {
            ingredients.push(ingredient);
            measures.push(measure || '');
          }
        }
        
        recipes.push({
          id: parseInt(meal.idMeal),
          title: meal.strMeal,
          image: meal.strMealThumb,
          readyInMinutes: 30, // Default
          servings: 4, // Default
          calories: Math.floor(Math.random() * 400) + 200, // Estimated
          ingredients: ingredients.map((ing, idx) => `${measures[idx]} ${ing}`.trim()),
          instructions: meal.strInstructions,
          summary: `Delicious ${meal.strCategory} dish from ${meal.strArea} cuisine.`
        });
      }
    }
    
    return recipes;
  } catch (error) {
    console.error('Error fetching MealDB recipes:', error);
    return [];
  }
};

// Search recipes by name using MealDB
export const searchMealDBRecipes = async (query: string): Promise<Recipe[]> => {
  try {
    const response = await fetch(`${MEALDB_BASE_URL}/search.php?s=${encodeURIComponent(query)}`);
    const data = await response.json();
    
    if (data.meals) {
      return data.meals.slice(0, 10).map((meal: any) => {
        const ingredients = [];
        const measures = [];
        
        for (let j = 1; j <= 20; j++) {
          const ingredient = meal[`strIngredient${j}`];
          const measure = meal[`strMeasure${j}`];
          if (ingredient && ingredient.trim()) {
            ingredients.push(ingredient);
            measures.push(measure || '');
          }
        }
        
        return {
          id: parseInt(meal.idMeal),
          title: meal.strMeal,
          image: meal.strMealThumb,
          readyInMinutes: 30,
          servings: 4,
          calories: Math.floor(Math.random() * 400) + 200,
          ingredients: ingredients.map((ing, idx) => `${measures[idx]} ${ing}`.trim()),
          instructions: meal.strInstructions,
          summary: `${meal.strCategory} dish from ${meal.strArea} cuisine.`
        };
      });
    }
    
    return [];
  } catch (error) {
    console.error('Error searching MealDB recipes:', error);
    return [];
  }
};

// Get meal categories from MealDB
export const getMealCategories = async (): Promise<string[]> => {
  try {
    const response = await fetch(`${MEALDB_BASE_URL}/categories.php`);
    const data = await response.json();
    
    if (data.categories) {
      return data.categories.map((cat: any) => cat.strCategory);
    }
    
    return [];
  } catch (error) {
    console.error('Error fetching meal categories:', error);
    return ['Beef', 'Chicken', 'Dessert', 'Lamb', 'Miscellaneous', 'Pasta', 'Pork', 'Seafood', 'Side', 'Starter', 'Vegan', 'Vegetarian'];
  }
};

// Generate AI cooking tips
export const generateCookingTip = (recipe: Recipe): string => {
  const tips = [
    `This ${recipe.title} is perfect for a ${recipe.readyInMinutes}-minute cooking session!`,
    `With ${recipe.calories || 'moderate'} calories per serving, this dish offers great nutritional value.`,
    `Pro tip: Prep all ingredients before starting - this recipe serves ${recipe.servings} people perfectly.`,
    `The combination of flavors in this dish will create an amazing dining experience!`,
    `This recipe is ideal for both beginners and experienced cooks alike.`,
    `Don't forget to taste as you go - cooking is all about adjusting to your preferences!`
  ];
  
  return tips[Math.floor(Math.random() * tips.length)];
};