const SPOTIFY_CLIENT_ID = '762c6d0c95e3457794a249413c62f56c';
const SPOTIFY_BASE_URL = 'https://api.spotify.com/v1';

export interface SpotifyTrack {
  id: string;
  name: string;
  artists: Array<{
    name: string;
  }>;
  album: {
    name: string;
    images: Array<{
      url: string;
      height: number;
      width: number;
    }>;
  };
  duration_ms: number;
  preview_url: string | null;
  external_urls: {
    spotify: string;
  };
}

export interface SpotifyPlaylist {
  id: string;
  name: string;
  description: string;
  images: Array<{
    url: string;
    height: number;
    width: number;
  }>;
  tracks: {
    total: number;
  };
  external_urls: {
    spotify: string;
  };
}

export interface SpotifyPodcast {
  id: string;
  name: string;
  description: string;
  images: Array<{
    url: string;
    height: number;
    width: number;
  }>;
  publisher: string;
  external_urls: {
    spotify: string;
  };
}

// Comprehensive mock music database with high-quality album covers
const mockMusicByMood = {
  'Happy': [
    {
      id: '1',
      name: 'Good as Hell',
      artists: [{ name: 'Lizzo' }],
      album: { 
        name: 'Cuz I Love You', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 219000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/1BxfuPKGuaTgP7aM0Bbdwr' }
    },
    {
      id: '2',
      name: 'Uptown Funk',
      artists: [{ name: 'Mark Ronson ft. Bruno Mars' }],
      album: { 
        name: 'Uptown Special', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 270000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/32OlwWuMpZ6b0aN2RZOeMS' }
    },
    {
      id: '3',
      name: 'Happy',
      artists: [{ name: 'Pharrell Williams' }],
      album: { 
        name: 'G I R L', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 232000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/60nZcImufyMA1MKQY3dcCH' }
    },
    {
      id: '4',
      name: 'Can\'t Stop the Feeling!',
      artists: [{ name: 'Justin Timberlake' }],
      album: { 
        name: 'Trolls (Original Motion Picture Soundtrack)', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 236000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/6KuQTIu1KoTTkLXKrwlLPV' }
    },
    {
      id: '5',
      name: 'Walking on Sunshine',
      artists: [{ name: 'Katrina and the Waves' }],
      album: { 
        name: 'Walking on Sunshine', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 239000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/05wIrZSwuaVWhcv5FfqeH0' }
    },
    {
      id: '6',
      name: 'I Gotta Feeling',
      artists: [{ name: 'The Black Eyed Peas' }],
      album: { 
        name: 'The E.N.D.', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1644888/pexels-photo-1644888.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 285000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/5uCax9HTNlzGybIStD3vDh' }
    },
    {
      id: '7',
      name: 'Shake It Off',
      artists: [{ name: 'Taylor Swift' }],
      album: { 
        name: '1989', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1370545/pexels-photo-1370545.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 219000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/0cqRj7pUJDkTCEsJkx8snD' }
    },
    {
      id: '8',
      name: 'Don\'t Worry Be Happy',
      artists: [{ name: 'Bobby McFerrin' }],
      album: { 
        name: 'Simple Pleasures', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1389429/pexels-photo-1389429.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 280000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/7Lf4nKJJZYNTZXRqspnmBc' }
    }
  ],
  'Sad': [
    {
      id: '9',
      name: 'Someone Like You',
      artists: [{ name: 'Adele' }],
      album: { 
        name: '21', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 285000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/1zwMYTA5nlNjZxYrvBB2pV' }
    },
    {
      id: '10',
      name: 'Mad World',
      artists: [{ name: 'Gary Jules' }],
      album: { 
        name: 'Donnie Darko Soundtrack', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1370545/pexels-photo-1370545.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 186000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/3JOVTQ5h8HGFnDdp4VT3MP' }
    },
    {
      id: '11',
      name: 'Hurt',
      artists: [{ name: 'Johnny Cash' }],
      album: { 
        name: 'American IV: The Man Comes Around', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1389429/pexels-photo-1389429.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 218000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/5Ej20dl6ge5wD7EkUXzgUG' }
    },
    {
      id: '12',
      name: 'Black',
      artists: [{ name: 'Pearl Jam' }],
      album: { 
        name: 'Ten', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1644888/pexels-photo-1644888.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 343000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/4qbCRlvE5Bb9XNBjxARjoP' }
    },
    {
      id: '13',
      name: 'Tears in Heaven',
      artists: [{ name: 'Eric Clapton' }],
      album: { 
        name: 'Unplugged', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 282000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/4bHsxqR3GMrXTxEPLuK5ue' }
    },
    {
      id: '14',
      name: 'The Sound of Silence',
      artists: [{ name: 'Simon & Garfunkel' }],
      album: { 
        name: 'Sounds of Silence', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 200000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/5xXqyjLicvEpch72qEryFT' }
    }
  ],
  'Energetic': [
    {
      id: '15',
      name: 'Thunder',
      artists: [{ name: 'Imagine Dragons' }],
      album: { 
        name: 'Evolve', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 187000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/1zB4vmk8tFRmM9UULNzbLB' }
    },
    {
      id: '16',
      name: 'Pump It',
      artists: [{ name: 'The Black Eyed Peas' }],
      album: { 
        name: 'Monkey Business', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 215000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/3ZOEytgrvLwQaqXreDs2Jx' }
    },
    {
      id: '17',
      name: 'Eye of the Tiger',
      artists: [{ name: 'Survivor' }],
      album: { 
        name: 'Eye of the Tiger', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 245000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/2KH16WveTQWT6KOG9Rg6e2' }
    },
    {
      id: '18',
      name: 'We Will Rock You',
      artists: [{ name: 'Queen' }],
      album: { 
        name: 'News of the World', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1370545/pexels-photo-1370545.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 122000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/4pbJqGIASGPr0ZpGpnWkDn' }
    },
    {
      id: '19',
      name: 'Stronger',
      artists: [{ name: 'Kelly Clarkson' }],
      album: { 
        name: 'Breakaway', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1389429/pexels-photo-1389429.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 222000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/0EkX7BRCk8zUtMkSHCQNJl' }
    },
    {
      id: '20',
      name: 'Titanium',
      artists: [{ name: 'David Guetta ft. Sia' }],
      album: { 
        name: 'Nothing but the Beat', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1644888/pexels-photo-1644888.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 245000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/0lYBSQXN6rCTvUZvg9S0lU' }
    }
  ],
  'Relaxed': [
    {
      id: '21',
      name: 'Weightless',
      artists: [{ name: 'Marconi Union' }],
      album: { 
        name: 'Ambient', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 480000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/6p0q6XoD75ZXtZZWzstNpb' }
    },
    {
      id: '22',
      name: 'Clair de Lune',
      artists: [{ name: 'Claude Debussy' }],
      album: { 
        name: 'Suite Bergamasque', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 300000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/4Iho4MyOuRRdQQvCl2LKzl' }
    },
    {
      id: '23',
      name: 'River',
      artists: [{ name: 'Joni Mitchell' }],
      album: { 
        name: 'Blue', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 240000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/3qQbCzHBycnDpGskqOWY0E' }
    },
    {
      id: '24',
      name: 'Mad About You',
      artists: [{ name: 'Sting' }],
      album: { 
        name: 'Ten Summoner\'s Tales', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 231000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/1Je1IMUlBXcx1Fz0WE7oPT' }
    },
    {
      id: '25',
      name: 'Breathe Me',
      artists: [{ name: 'Sia' }],
      album: { 
        name: 'Colour the Small One', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 268000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/6p0q6XoD75ZXtZZWzstNpb' }
    }
  ],
  'Focused': [
    {
      id: '26',
      name: 'Ludovico Einaudi - Nuvole Bianche',
      artists: [{ name: 'Ludovico Einaudi' }],
      album: { 
        name: 'Una Mattina', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1370545/pexels-photo-1370545.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 348000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/7maJOTL3bHOaK8p8TzpC8B' }
    },
    {
      id: '27',
      name: 'Gymnopédie No. 1',
      artists: [{ name: 'Erik Satie' }],
      album: { 
        name: 'Gymnopédies', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1389429/pexels-photo-1389429.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 210000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/0lYBSQXN6rCTvUZvg9S0lU' }
    },
    {
      id: '28',
      name: 'Porcelain',
      artists: [{ name: 'Moby' }],
      album: { 
        name: 'Play', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1644888/pexels-photo-1644888.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 240000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/7maJOTL3bHOaK8p8TzpC8B' }
    },
    {
      id: '29',
      name: 'Teardrop',
      artists: [{ name: 'Massive Attack' }],
      album: { 
        name: 'Mezzanine', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 329000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/6p0q6XoD75ZXtZZWzstNpb' }
    }
  ],
  'Romantic': [
    {
      id: '30',
      name: 'Perfect',
      artists: [{ name: 'Ed Sheeran' }],
      album: { 
        name: '÷ (Divide)', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 263000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/0tgVpDi06FyKpA1z0VMD4v' }
    },
    {
      id: '31',
      name: 'All of Me',
      artists: [{ name: 'John Legend' }],
      album: { 
        name: 'Love in the Future', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 269000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/3U4isOIWM3VvDubwSI3y7a' }
    },
    {
      id: '32',
      name: 'Thinking Out Loud',
      artists: [{ name: 'Ed Sheeran' }],
      album: { 
        name: 'x (Multiply)', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 281000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/1KiHpiYP2grQwdQNXPJuVX' }
    },
    {
      id: '33',
      name: 'Make You Feel My Love',
      artists: [{ name: 'Adele' }],
      album: { 
        name: '19', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 231000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/4WXddlQqjl0aZnFbZhQZDy' }
    },
    {
      id: '34',
      name: 'At Last',
      artists: [{ name: 'Etta James' }],
      album: { 
        name: 'At Last!', 
        images: [{ 
          url: 'https://images.pexels.com/photos/1370545/pexels-photo-1370545.jpeg?auto=compress&cs=tinysrgb&w=400', 
          height: 400, 
          width: 400 
        }] 
      },
      duration_ms: 180000,
      preview_url: null,
      external_urls: { spotify: 'https://open.spotify.com/track/4Iho4MyOuRRdQQvCl2LKzl' }
    }
  ]
};

const mockPodcasts = [
  {
    id: '1',
    name: 'The Joe Rogan Experience',
    description: 'Long form conversations with interesting people from all walks of life',
    images: [{ url: 'https://images.pexels.com/photos/7045617/pexels-photo-7045617.jpeg?auto=compress&cs=tinysrgb&w=400', height: 400, width: 400 }],
    publisher: 'Joe Rogan',
    external_urls: { spotify: 'https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk' }
  },
  {
    id: '2',
    name: 'TED Talks Daily',
    description: 'Ideas worth spreading, every day. Fresh talks from TED speakers',
    images: [{ url: 'https://images.pexels.com/photos/7045617/pexels-photo-7045617.jpeg?auto=compress&cs=tinysrgb&w=400', height: 400, width: 400 }],
    publisher: 'TED',
    external_urls: { spotify: 'https://open.spotify.com/show/1VXcH8QHkjRcTCEd88U3ti' }
  },
  {
    id: '3',
    name: 'Serial',
    description: 'One story told week by week. Investigative journalism at its finest',
    images: [{ url: 'https://images.pexels.com/photos/7045617/pexels-photo-7045617.jpeg?auto=compress&cs=tinysrgb&w=400', height: 400, width: 400 }],
    publisher: 'Serial Productions',
    external_urls: { spotify: 'https://open.spotify.com/show/6ll0MwobDt1JW9gYaOONEo' }
  },
  {
    id: '4',
    name: 'This American Life',
    description: 'Stories of life in America, told with humor and insight',
    images: [{ url: 'https://images.pexels.com/photos/7045617/pexels-photo-7045617.jpeg?auto=compress&cs=tinysrgb&w=400', height: 400, width: 400 }],
    publisher: 'This American Life',
    external_urls: { spotify: 'https://open.spotify.com/show/2MAi0BvDc6GTFvKFPXnkCL' }
  },
  {
    id: '5',
    name: 'Conan O\'Brien Needs a Friend',
    description: 'Comedy legend Conan O\'Brien chats with friends and celebrities',
    images: [{ url: 'https://images.pexels.com/photos/7045617/pexels-photo-7045617.jpeg?auto=compress&cs=tinysrgb&w=400', height: 400, width: 400 }],
    publisher: 'Team Coco & Earwolf',
    external_urls: { spotify: 'https://open.spotify.com/show/1VXcH8QHkjRcTCEd88U3ti' }
  },
  {
    id: '6',
    name: 'Radiolab',
    description: 'Science, philosophy, and human experience explored through sound',
    images: [{ url: 'https://images.pexels.com/photos/7045617/pexels-photo-7045617.jpeg?auto=compress&cs=tinysrgb&w=400', height: 400, width: 400 }],
    publisher: 'WNYC Studios',
    external_urls: { spotify: 'https://open.spotify.com/show/2hmkzUtix0qTqvtpPcMzEL' }
  }
];

export const getMusicByMood = async (mood: string): Promise<SpotifyTrack[]> => {
  try {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const tracks = mockMusicByMood[mood as keyof typeof mockMusicByMood] || mockMusicByMood['Happy'];
    
    // Shuffle and return all tracks for variety
    return [...tracks].sort(() => Math.random() - 0.5);
  } catch (error) {
    console.error('Error fetching music:', error);
    return [];
  }
};

export const getPopularPodcasts = async (): Promise<SpotifyPodcast[]> => {
  try {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockPodcasts;
  } catch (error) {
    console.error('Error fetching podcasts:', error);
    return [];
  }
};

export const formatDuration = (ms: number): string => {
  const minutes = Math.floor(ms / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
};

export const openInSpotify = (url: string) => {
  window.open(url, '_blank');
};