const OMDB_API_KEY = '6176489b';
const OMDB_BASE_URL = 'https://www.omdbapi.com/';

export interface Movie {
  Title: string;
  Year: string;
  Rated: string;
  Released: string;
  Runtime: string;
  Genre: string;
  Director: string;
  Writer: string;
  Actors: string;
  Plot: string;
  Language: string;
  Country: string;
  Awards: string;
  Poster: string;
  Ratings: Array<{
    Source: string;
    Value: string;
  }>;
  Metascore: string;
  imdbRating: string;
  imdbVotes: string;
  imdbID: string;
  Type: string;
  DVD: string;
  BoxOffice: string;
  Production: string;
  Website: string;
  Response: string;
}

export interface SearchResult {
  Search: Array<{
    Title: string;
    Year: string;
    imdbID: string;
    Type: string;
    Poster: string;
  }>;
  totalResults: string;
  Response: string;
}

// Expanded movie suggestions based on moods with search terms
const moodBasedSearchTerms = {
  'Happy': ['comedy', 'feel good', 'adventure', 'animated', 'musical', 'family', 'uplifting', 'cheerful'],
  'Sad': ['drama', 'romance', 'biographical', 'historical', 'tearjerker', 'emotional', 'melancholy', 'touching'],
  'Excited': ['action', 'thriller', 'superhero', 'adventure', 'sci-fi', 'fast paced', 'intense', 'explosive'],
  'Relaxed': ['documentary', 'nature', 'slice of life', 'indie', 'peaceful', 'calm', 'meditative', 'gentle'],
  'Curious': ['mystery', 'sci-fi', 'documentary', 'psychological', 'crime', 'puzzle', 'investigation', 'mind bending'],
  'Romantic': ['romance', 'romantic comedy', 'love story', 'wedding', 'date night', 'passionate', 'heartwarming', 'sweet']
};

// Massive collection of popular movie IDs for each mood
const moodBasedMovieIds = {
  'Happy': [
    // Comedies & Feel-Good Movies
    'tt0120737', // The Lord of the Rings: The Fellowship of the Ring
    'tt0317219', // Shrek 2
    'tt0266543', // Finding Nemo
    'tt0120815', // Saving Private Ryan
    'tt0110912', // Pulp Fiction
    'tt0109830', // Forrest Gump
    'tt0111161', // The Shawshank Redemption
    'tt0068646', // The Godfather
    'tt0071562', // The Godfather: Part II
    'tt0468569', // The Dark Knight
    'tt0050083', // 12 Angry Men
    'tt0108052', // Schindler's List
    'tt0167260', // The Lord of the Rings: The Return of the King
    'tt0110413', // Léon: The Professional
    'tt0060196', // The Good, the Bad and the Ugly
    'tt0137523', // Fight Club
    'tt0120689', // The Green Mile
    'tt0133093', // The Matrix
    'tt0080684', // Star Wars: Episode V - The Empire Strikes Back
    'tt0099685', // Goodfellas
    'tt0073486', // One Flew Over the Cuckoo's Nest
    'tt0047478', // Seven Samurai
    'tt0114369', // Se7en
    'tt0102926', // The Silence of the Lambs
    'tt0038650', // It's a Wonderful Life
    'tt0076759', // Star Wars: Episode IV - A New Hope
    'tt0118799', // Life Is Beautiful
    'tt0816692', // Interstellar
    'tt0245429', // Spirited Away
    'tt1375666', // Inception
  ],
  'Sad': [
    // Dramas & Emotional Movies
    'tt0111161', // The Shawshank Redemption
    'tt0068646', // The Godfather
    'tt0108052', // Schindler's List
    'tt0167260', // The Lord of the Rings: The Return of the King
    'tt0110413', // Léon: The Professional
    'tt0120689', // The Green Mile
    'tt0073486', // One Flew Over the Cuckoo's Nest
    'tt0038650', // It's a Wonderful Life
    'tt0118799', // Life Is Beautiful
    'tt0993846', // The Wolf of Wall Street
    'tt0482571', // The Prestige
    'tt0407887', // The Departed
    'tt0253474', // The Pianist
    'tt0172495', // Gladiator
    'tt0103064', // Terminator 2: Judgment Day
    'tt0088763', // Back to the Future
    'tt0078748', // Alien
    'tt0078788', // Apocalypse Now
    'tt0095327', // The Shining
    'tt0054215', // Psycho
    'tt0027977', // Modern Times
    'tt0021749', // City Lights
    'tt0043014', // Sunset Boulevard
    'tt0056172', // Lawrence of Arabia
    'tt0057012', // Dr. Strangelove
    'tt0066921', // A Clockwork Orange
    'tt0075314', // Taxi Driver
    'tt0081505', // The Elephant Man
    'tt0086190', // Scarface
    'tt0090605', // Aliens
  ],
  'Excited': [
    // Action & Thrillers
    'tt0468569', // The Dark Knight
    'tt0137523', // Fight Club
    'tt0133093', // The Matrix
    'tt0080684', // Star Wars: Episode V - The Empire Strikes Back
    'tt0099685', // Goodfellas
    'tt0114369', // Se7en
    'tt0102926', // The Silence of the Lambs
    'tt0076759', // Star Wars: Episode IV - A New Hope
    'tt1375666', // Inception
    'tt0816692', // Interstellar
    'tt0482571', // The Prestige
    'tt0407887', // The Departed
    'tt0172495', // Gladiator
    'tt0103064', // Terminator 2: Judgment Day
    'tt0088763', // Back to the Future
    'tt0078748', // Alien
    'tt0078788', // Apocalypse Now
    'tt0095327', // The Shining
    'tt0054215', // Psycho
    'tt0086190', // Scarface
    'tt0090605', // Aliens
    'tt0120815', // Saving Private Ryan
    'tt0110912', // Pulp Fiction
    'tt0109830', // Forrest Gump
    'tt0071562', // The Godfather: Part II
    'tt0060196', // The Good, the Bad and the Ugly
    'tt0047478', // Seven Samurai
    'tt0253474', // The Pianist
    'tt0027977', // Modern Times
    'tt0021749', // City Lights
  ],
  'Relaxed': [
    // Peaceful & Contemplative
    'tt0245429', // Spirited Away
    'tt0816692', // Interstellar
    'tt1049413', // Up
    'tt0993846', // The Wolf of Wall Street
    'tt0758758', // Into the Wild
    'tt0338013', // Eternal Sunshine of the Spotless Mind
    'tt0112384', // Apollo 13
    'tt0268978', // A Beautiful Mind
    'tt0364569', // Oldboy
    'tt0056172', // Lawrence of Arabia
    'tt0057012', // Dr. Strangelove
    'tt0066921', // A Clockwork Orange
    'tt0075314', // Taxi Driver
    'tt0081505', // The Elephant Man
    'tt0043014', // Sunset Boulevard
    'tt0118799', // Life Is Beautiful
    'tt0038650', // It's a Wonderful Life
    'tt0073486', // One Flew Over the Cuckoo's Nest
    'tt0120689', // The Green Mile
    'tt0110413', // Léon: The Professional
    'tt0167260', // The Lord of the Rings: The Return of the King
    'tt0108052', // Schindler's List
    'tt0068646', // The Godfather
    'tt0111161', // The Shawshank Redemption
    'tt0317219', // Shrek 2
    'tt0266543', // Finding Nemo
    'tt0120737', // The Lord of the Rings: The Fellowship of the Ring
    'tt0109830', // Forrest Gump
    'tt0110912', // Pulp Fiction
    'tt0120815', // Saving Private Ryan
  ],
  'Curious': [
    // Mystery & Sci-Fi
    'tt0114369', // Se7en
    'tt0816692', // Interstellar
    'tt0482571', // The Prestige
    'tt0993846', // The Wolf of Wall Street
    'tt0338013', // Eternal Sunshine of the Spotless Mind
    'tt1375666', // Inception
    'tt0133093', // The Matrix
    'tt0137523', // Fight Club
    'tt0468569', // The Dark Knight
    'tt0102926', // The Silence of the Lambs
    'tt0078748', // Alien
    'tt0095327', // The Shining
    'tt0054215', // Psycho
    'tt0057012', // Dr. Strangelove
    'tt0066921', // A Clockwork Orange
    'tt0075314', // Taxi Driver
    'tt0081505', // The Elephant Man
    'tt0090605', // Aliens
    'tt0407887', // The Departed
    'tt0364569', // Oldboy
    'tt0268978', // A Beautiful Mind
    'tt0112384', // Apollo 13
    'tt0758758', // Into the Wild
    'tt0245429', // Spirited Away
    'tt1049413', // Up
    'tt0172495', // Gladiator
    'tt0103064', // Terminator 2: Judgment Day
    'tt0088763', // Back to the Future
    'tt0078788', // Apocalypse Now
    'tt0086190', // Scarface
  ],
  'Romantic': [
    // Romance & Love Stories
    'tt0338013', // Eternal Sunshine of the Spotless Mind
    'tt0112384', // Apollo 13
    'tt0317219', // Shrek 2
    'tt0268978', // A Beautiful Mind
    'tt0364569', // Oldboy
    'tt0118799', // Life Is Beautiful
    'tt0038650', // It's a Wonderful Life
    'tt0043014', // Sunset Boulevard
    'tt0056172', // Lawrence of Arabia
    'tt0021749', // City Lights
    'tt0027977', // Modern Times
    'tt0253474', // The Pianist
    'tt0172495', // Gladiator
    'tt0120689', // The Green Mile
    'tt0073486', // One Flew Over the Cuckoo's Nest
    'tt0110413', // Léon: The Professional
    'tt0167260', // The Lord of the Rings: The Return of the King
    'tt0108052', // Schindler's List
    'tt0068646', // The Godfather
    'tt0111161', // The Shawshank Redemption
    'tt0758758', // Into the Wild
    'tt1049413', // Up
    'tt0245429', // Spirited Away
    'tt0816692', // Interstellar
    'tt0993846', // The Wolf of Wall Street
    'tt0482571', // The Prestige
    'tt1375666', // Inception
    'tt0407887', // The Departed
    'tt0133093', // The Matrix
    'tt0137523', // Fight Club
  ]
};

export const searchMoviesByMood = async (mood: string): Promise<Movie[]> => {
  try {
    const movieIds = moodBasedMovieIds[mood as keyof typeof moodBasedMovieIds] || [];
    
    // Shuffle the array and take 15 random movies for variety
    const shuffledIds = [...movieIds].sort(() => Math.random() - 0.5);
    const selectedIds = shuffledIds.slice(0, 15);
    
    // Get movies by specific IDs for reliable results
    const moviePromises = selectedIds.map(id => getMovieById(id));
    const movies = await Promise.all(moviePromises);
    
    // Filter out any failed requests
    const validMovies = movies.filter(movie => movie && movie.Response === 'True');
    
    if (validMovies.length > 0) {
      return validMovies;
    }
    
    // Fallback to search if direct ID lookup fails
    const searchTerms = moodBasedSearchTerms[mood as keyof typeof moodBasedSearchTerms] || ['popular'];
    const searchTerm = searchTerms[Math.floor(Math.random() * searchTerms.length)];
    const searchResults = await searchMovies(searchTerm);
    
    if (searchResults && searchResults.Search) {
      const detailedMovies = await Promise.all(
        searchResults.Search.slice(0, 10).map(result => getMovieById(result.imdbID))
      );
      return detailedMovies.filter(movie => movie && movie.Response === 'True');
    }
    
    return [];
  } catch (error) {
    console.error('Error fetching movies by mood:', error);
    return [];
  }
};

export const searchMovies = async (query: string, year?: string): Promise<SearchResult | null> => {
  try {
    let url = `${OMDB_BASE_URL}?apikey=${OMDB_API_KEY}&s=${encodeURIComponent(query)}`;
    if (year) {
      url += `&y=${year}`;
    }
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.Response === 'True') {
      return data;
    }
    
    return null;
  } catch (error) {
    console.error('Error searching movies:', error);
    return null;
  }
};

export const getMovieById = async (imdbId: string): Promise<Movie | null> => {
  try {
    const url = `${OMDB_BASE_URL}?apikey=${OMDB_API_KEY}&i=${imdbId}&plot=short`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.Response === 'True') {
      return data;
    }
    
    return null;
  } catch (error) {
    console.error('Error fetching movie details:', error);
    return null;
  }
};

export const generateAIDescription = (movie: Movie, mood: string): string => {
  const moodDescriptions = {
    'Happy': [
      "This delightful film will lift your spirits and leave you with a smile that lasts for hours!",
      "Pure joy in movie form - exactly what you need to brighten your day!",
      "A feel-good masterpiece that proves cinema can be the perfect mood booster!",
      "Get ready to laugh, cheer, and feel absolutely wonderful about life!",
      "The perfect antidote to any bad day - guaranteed to make you smile!",
      "Uplifting storytelling that will restore your faith in humanity and happiness!"
    ],
    'Sad': [
      "A deeply moving experience that will touch your heart and soul.",
      "This emotional journey offers catharsis and beautiful storytelling that resonates long after the credits roll.",
      "Prepare for a profound cinematic experience that explores the depths of human emotion.",
      "A touching masterpiece that reminds us of the beauty in life's most poignant moments.",
      "An emotionally rich film that provides comfort through shared human experience.",
      "A powerful drama that will leave you feeling deeply moved and contemplative."
    ],
    'Excited': [
      "Buckle up for an adrenaline-pumping ride that will keep you on the edge of your seat!",
      "This high-octane thriller delivers non-stop excitement and jaw-dropping moments!",
      "Get ready for heart-racing action that will leave you breathless and wanting more!",
      "An electrifying experience that perfectly captures the thrill you're craving!",
      "Pure adrenaline rush - this film will have your heart pounding from start to finish!",
      "Explosive entertainment that delivers exactly the excitement you're looking for!"
    ],
    'Relaxed': [
      "The perfect film to unwind with - beautifully paced and wonderfully soothing.",
      "A gentle, contemplative journey that's ideal for a peaceful evening.",
      "Sit back and let this calming cinematic experience wash over you.",
      "The ultimate comfort movie that's like a warm hug for your soul.",
      "Peaceful storytelling that creates the perfect atmosphere for relaxation.",
      "A meditative film experience that will help you find your inner calm."
    ],
    'Curious': [
      "A mind-bending journey that will challenge your perceptions and leave you thinking for days.",
      "Prepare to have your curiosity satisfied with this intellectually stimulating masterpiece.",
      "This thought-provoking film offers layers of meaning waiting to be discovered.",
      "A fascinating exploration that perfectly feeds your inquisitive mind.",
      "Complex storytelling that rewards careful attention and deep thinking.",
      "An intriguing puzzle of a film that will keep your mind engaged throughout."
    ],
    'Romantic': [
      "A swoon-worthy love story that will make your heart flutter with every scene.",
      "The perfect romantic escape that celebrates love in all its beautiful forms.",
      "Get ready to fall in love with love all over again with this enchanting tale.",
      "A heartwarming romance that proves true love stories never go out of style.",
      "Pure romantic magic that will leave you believing in the power of love.",
      "An enchanting love story that captures all the butterflies and magic of romance."
    ]
  };
  
  const descriptions = moodDescriptions[mood as keyof typeof moodDescriptions] || [
    "A captivating film that's perfect for your current mood and viewing preferences."
  ];
  
  return descriptions[Math.floor(Math.random() * descriptions.length)];
};

// Helper function to truncate plot for shorter display
export const getShortPlot = (plot: string, maxLength: number = 120): string => {
  if (plot.length <= maxLength) return plot;
  
  const truncated = plot.substring(0, maxLength);
  const lastSpace = truncated.lastIndexOf(' ');
  
  return lastSpace > 0 ? truncated.substring(0, lastSpace) + '...' : truncated + '...';
};