const GEOAPIFY_API_KEY = 'd81f9de98c4a4382a35e9501f84c1020';
const GEOAPIFY_BASE_URL = 'https://api.geoapify.com/v2';

export interface Place {
  place_id: string;
  name: string;
  formatted: string;
  address_line1?: string;
  address_line2?: string;
  city?: string;
  state?: string;
  postcode?: string;
  country?: string;
  lat: number;
  lon: number;
  distance?: number;
  categories: string[];
  details?: {
    contact?: {
      phone?: string;
      website?: string;
    };
    facilities?: string[];
    opening_hours?: string;
    rating?: number;
    reviews_count?: number;
  };
}

export interface UserLocation {
  lat: number;
  lon: number;
  city?: string;
  country?: string;
}

// Get user's current location
export const getCurrentLocation = (): Promise<UserLocation> => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by this browser'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;
        
        try {
          // Reverse geocode to get city name
          const locationInfo = await reverseGeocode(lat, lon);
          resolve({
            lat,
            lon,
            city: locationInfo?.city,
            country: locationInfo?.country
          });
        } catch (error) {
          // Return coordinates even if reverse geocoding fails
          resolve({ lat, lon });
        }
      },
      (error) => {
        // Fallback to a default location (New York City)
        console.warn('Geolocation failed, using default location:', error);
        resolve({
          lat: 40.7128,
          lon: -74.0060,
          city: 'New York',
          country: 'United States'
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    );
  });
};

// Reverse geocode coordinates to get location info
export const reverseGeocode = async (lat: number, lon: number): Promise<any> => {
  try {
    const response = await fetch(
      `${GEOAPIFY_BASE_URL}/geocode/reverse?lat=${lat}&lon=${lon}&apiKey=${GEOAPIFY_API_KEY}`
    );
    const data = await response.json();
    
    if (data.features && data.features.length > 0) {
      return data.features[0].properties;
    }
    return null;
  } catch (error) {
    console.error('Reverse geocoding failed:', error);
    return null;
  }
};

// Search for places by category near a location
export const searchPlaces = async (
  category: string,
  lat: number,
  lon: number,
  radius: number = 5000,
  limit: number = 20
): Promise<Place[]> => {
  try {
    const response = await fetch(
      `${GEOAPIFY_BASE_URL}/places?categories=${category}&filter=circle:${lon},${lat},${radius}&bias=proximity:${lon},${lat}&limit=${limit}&apiKey=${GEOAPIFY_API_KEY}`
    );
    
    const data = await response.json();
    
    if (data.features) {
      return data.features.map((feature: any) => ({
        place_id: feature.properties.place_id,
        name: feature.properties.name || 'Unknown',
        formatted: feature.properties.formatted || '',
        address_line1: feature.properties.address_line1,
        address_line2: feature.properties.address_line2,
        city: feature.properties.city,
        state: feature.properties.state,
        postcode: feature.properties.postcode,
        country: feature.properties.country,
        lat: feature.geometry.coordinates[1],
        lon: feature.geometry.coordinates[0],
        distance: feature.properties.distance,
        categories: feature.properties.categories || [],
        details: {
          contact: {
            phone: feature.properties.contact?.phone,
            website: feature.properties.contact?.website
          },
          facilities: feature.properties.facilities,
          opening_hours: feature.properties.opening_hours,
          rating: feature.properties.rating,
          reviews_count: feature.properties.reviews_count
        }
      }));
    }
    
    return [];
  } catch (error) {
    console.error('Places search failed:', error);
    return [];
  }
};

// Get restaurants by cuisine type
export const getRestaurantsByCuisine = async (
  cuisine: string,
  lat: number,
  lon: number,
  radius: number = 5000
): Promise<Place[]> => {
  const cuisineCategories: { [key: string]: string } = {
    'Italian': 'catering.restaurant.italian',
    'Asian': 'catering.restaurant.asian',
    'Mexican': 'catering.restaurant.mexican',
    'American': 'catering.restaurant.american',
    'Mediterranean': 'catering.restaurant.mediterranean',
    'Indian': 'catering.restaurant.indian',
    'Chinese': 'catering.restaurant.chinese',
    'Japanese': 'catering.restaurant.japanese',
    'Thai': 'catering.restaurant.thai',
    'French': 'catering.restaurant.french'
  };

  const category = cuisineCategories[cuisine] || 'catering.restaurant';
  return await searchPlaces(category, lat, lon, radius, 15);
};

// Get supermarkets and grocery stores
export const getSupermarkets = async (
  lat: number,
  lon: number,
  radius: number = 10000
): Promise<Place[]> => {
  return await searchPlaces('commercial.supermarket,commercial.marketplace', lat, lon, radius, 10);
};

// Get activities and entertainment venues
export const getActivitiesNearby = async (
  activityType: string,
  lat: number,
  lon: number,
  radius: number = 15000
): Promise<Place[]> => {
  const activityCategories: { [key: string]: string } = {
    'entertainment': 'entertainment,leisure',
    'museums': 'entertainment.museum',
    'parks': 'leisure.park',
    'shopping': 'commercial.shopping_mall,commercial.marketplace',
    'sports': 'sport',
    'nightlife': 'entertainment.nightlife',
    'culture': 'entertainment.culture',
    'outdoor': 'leisure.outdoor'
  };

  const category = activityCategories[activityType] || 'entertainment,leisure';
  return await searchPlaces(category, lat, lon, radius, 15);
};

// Calculate distance between two points
export const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c; // Distance in kilometers
  return Math.round(distance * 100) / 100; // Round to 2 decimal places
};

// Format distance for display
export const formatDistance = (distance: number): string => {
  if (distance < 1) {
    return `${Math.round(distance * 1000)}m`;
  }
  return `${distance}km`;
};

// Get place details by ID
export const getPlaceDetails = async (placeId: string): Promise<Place | null> => {
  try {
    const response = await fetch(
      `${GEOAPIFY_BASE_URL}/place-details?id=${placeId}&apiKey=${GEOAPIFY_API_KEY}`
    );
    
    const data = await response.json();
    
    if (data.features && data.features.length > 0) {
      const feature = data.features[0];
      return {
        place_id: feature.properties.place_id,
        name: feature.properties.name || 'Unknown',
        formatted: feature.properties.formatted || '',
        address_line1: feature.properties.address_line1,
        address_line2: feature.properties.address_line2,
        city: feature.properties.city,
        state: feature.properties.state,
        postcode: feature.properties.postcode,
        country: feature.properties.country,
        lat: feature.geometry.coordinates[1],
        lon: feature.geometry.coordinates[0],
        categories: feature.properties.categories || [],
        details: {
          contact: {
            phone: feature.properties.contact?.phone,
            website: feature.properties.contact?.website
          },
          facilities: feature.properties.facilities,
          opening_hours: feature.properties.opening_hours,
          rating: feature.properties.rating,
          reviews_count: feature.properties.reviews_count
        }
      };
    }
    
    return null;
  } catch (error) {
    console.error('Place details fetch failed:', error);
    return null;
  }
};