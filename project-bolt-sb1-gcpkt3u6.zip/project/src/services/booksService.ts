const GOOGLE_BOOKS_API_KEY = 'AIzaSyAr7cWI0D21R1Im4KE-t9WIM8kILYZi22Q';
const GOOGLE_BOOKS_BASE_URL = 'https://www.googleapis.com/books/v1/volumes';
const OPEN_LIBRARY_BASE_URL = 'https://openlibrary.org';

export interface Book {
  id: string;
  title: string;
  authors: string[];
  description?: string;
  publishedDate?: string;
  pageCount?: number;
  categories?: string[];
  averageRating?: number;
  ratingsCount?: number;
  thumbnail?: string;
  previewLink?: string;
  infoLink?: string;
  isbn?: string;
}

export interface OpenLibraryBook {
  title: string;
  author: string;
  year: string;
  cover: string | null;
  link: string;
  key: string;
}

// Book topics with search terms
const bookTopics = {
  'Business': ['business', 'entrepreneurship', 'leadership', 'management', 'startup', 'marketing', 'finance', 'economics'],
  'Philosophy': ['philosophy', 'ethics', 'wisdom', 'thinking', 'consciousness', 'existentialism', 'stoicism', 'metaphysics'],
  'Self Development': ['self help', 'personal development', 'motivation', 'habits', 'productivity', 'mindfulness', 'success'],
  'Stories for Kids': ['children', 'kids', 'fairy tales', 'picture books', 'young readers', 'bedtime stories', 'educational'],
  'Fantasy Fiction': ['fantasy', 'magic', 'dragons', 'wizards', 'epic fantasy', 'urban fantasy', 'mythology', 'adventure'],
  'Historical': ['history', 'historical fiction', 'biography', 'world war', 'ancient history', 'medieval', 'renaissance'],
  'Science Fiction': ['science fiction', 'sci-fi', 'space', 'future', 'technology', 'dystopian', 'cyberpunk', 'aliens'],
  'Romance': ['romance', 'love story', 'romantic fiction', 'contemporary romance', 'historical romance', 'relationships'],
  'Mystery & Thriller': ['mystery', 'thriller', 'crime', 'detective', 'suspense', 'murder', 'investigation', 'police'],
  'Health & Fitness': ['health', 'fitness', 'nutrition', 'wellness', 'exercise', 'diet', 'mental health', 'medicine'],
  'Technology': ['technology', 'programming', 'computer science', 'artificial intelligence', 'coding', 'software', 'digital'],
  'Psychology': ['psychology', 'human behavior', 'cognitive science', 'mental health', 'neuroscience', 'therapy', 'mind'],
  'Biography': ['biography', 'memoir', 'autobiography', 'life story', 'famous people', 'historical figures', 'celebrities'],
  'Science & Nature': ['science', 'nature', 'biology', 'physics', 'chemistry', 'environment', 'animals', 'evolution'],
  'Art & Creativity': ['art', 'creativity', 'design', 'drawing', 'painting', 'photography', 'music', 'creative writing'],
  'Travel & Adventure': ['travel', 'adventure', 'exploration', 'travel guide', 'culture', 'geography', 'wanderlust']
};

// Popular book recommendations by topic
const popularBooks = {
  'Business': [
    'The Lean Startup', 'Good to Great', 'The 7 Habits of Highly Effective People', 
    'Think and Grow Rich', 'Rich Dad Poor Dad', 'The E-Myth Revisited'
  ],
  'Philosophy': [
    'Meditations', 'The Republic', 'Being and Time', 'The Nicomachean Ethics', 
    'Thus Spoke Zarathustra', 'The Art of War'
  ],
  'Self Development': [
    'Atomic Habits', 'The Power of Now', 'How to Win Friends and Influence People',
    'Mindset', 'The 4-Hour Workweek', 'Emotional Intelligence'
  ],
  'Stories for Kids': [
    'Harry Potter', 'The Chronicles of Narnia', 'Charlotte\'s Web', 'Where the Wild Things Are',
    'The Cat in the Hat', 'Matilda'
  ],
  'Fantasy Fiction': [
    'The Lord of the Rings', 'Game of Thrones', 'The Name of the Wind', 'The Way of Kings',
    'The Hobbit', 'Mistborn'
  ],
  'Historical': [
    'Sapiens', 'The Guns of August', 'A People\'s History of the United States',
    'The Diary of a Young Girl', 'Band of Brothers', 'The Book Thief'
  ],
  'Science Fiction': [
    'Dune', 'Foundation', 'The Hitchhiker\'s Guide to the Galaxy', 'Ender\'s Game',
    'The Martian', 'Ready Player One'
  ],
  'Romance': [
    'Pride and Prejudice', 'The Notebook', 'Me Before You', 'The Fault in Our Stars',
    'Outlander', 'The Time Traveler\'s Wife'
  ],
  'Mystery & Thriller': [
    'Gone Girl', 'The Girl with the Dragon Tattoo', 'The Da Vinci Code',
    'Sherlock Holmes', 'The Silent Patient', 'Big Little Lies'
  ],
  'Health & Fitness': [
    'Becoming Supernatural', 'The Blue Zones', 'How Not to Die', 'Atomic Habits',
    'The Power of Now', 'Why We Sleep'
  ],
  'Technology': [
    'The Innovators', 'Steve Jobs', 'The Everything Store', 'The Code Breaker',
    'Weapons of Math Destruction', 'The Age of Surveillance Capitalism'
  ],
  'Psychology': [
    'Thinking, Fast and Slow', 'The Power of Habit', 'Influence', 'Mindset',
    'The Happiness Hypothesis', 'Flow'
  ],
  'Biography': [
    'Steve Jobs', 'Becoming', 'The Diary of a Young Girl', 'Long Walk to Freedom',
    'Einstein', 'Benjamin Franklin'
  ],
  'Science & Nature': [
    'A Brief History of Time', 'The Origin of Species', 'Silent Spring', 'Cosmos',
    'The Selfish Gene', 'The Hidden Life of Trees'
  ],
  'Art & Creativity': [
    'The Artist\'s Way', 'Big Magic', 'Steal Like an Artist', 'The War of Art',
    'Drawing on the Right Side of the Brain', 'The Creative Habit'
  ],
  'Travel & Adventure': [
    'Into the Wild', 'A Walk in the Woods', 'Eat, Pray, Love', 'The Beach',
    'Wild', 'On the Road'
  ]
};

// Search books using Google Books API
export const searchBooks = async (query: string, maxResults: number = 20): Promise<Book[]> => {
  try {
    const response = await fetch(
      `${GOOGLE_BOOKS_BASE_URL}?q=${encodeURIComponent(query)}&maxResults=${maxResults}&key=${GOOGLE_BOOKS_API_KEY}`
    );
    
    if (!response.ok) {
      console.warn('Google Books API request failed, falling back to Open Library');
      return await searchOpenLibraryBooks(query);
    }
    
    const data = await response.json();
    
    if (data.items) {
      return data.items.map((item: any) => ({
        id: item.id,
        title: item.volumeInfo.title || 'Unknown Title',
        authors: item.volumeInfo.authors || ['Unknown Author'],
        description: item.volumeInfo.description,
        publishedDate: item.volumeInfo.publishedDate,
        pageCount: item.volumeInfo.pageCount,
        categories: item.volumeInfo.categories,
        averageRating: item.volumeInfo.averageRating,
        ratingsCount: item.volumeInfo.ratingsCount,
        thumbnail: item.volumeInfo.imageLinks?.thumbnail?.replace('http:', 'https:'),
        previewLink: item.volumeInfo.previewLink,
        infoLink: item.volumeInfo.infoLink,
        isbn: item.volumeInfo.industryIdentifiers?.[0]?.identifier
      }));
    }
    
    return [];
  } catch (error) {
    console.error('Error searching Google Books:', error);
    return await searchOpenLibraryBooks(query);
  }
};

// Search books using Open Library API as fallback
export const searchOpenLibraryBooks = async (query: string): Promise<Book[]> => {
  try {
    const url = `${OPEN_LIBRARY_BASE_URL}/search.json?q=${encodeURIComponent(query)}&fields=title,author_name,first_publish_year,cover_i,key&limit=10`;
    
    const response = await fetch(url);
    const data = await response.json();
    
    return data.docs.map((book: any, index: number) => ({
      id: book.key || `ol-${index}`,
      title: book.title || 'Unknown Title',
      authors: book.author_name || ['Unknown Author'],
      publishedDate: book.first_publish_year?.toString(),
      thumbnail: book.cover_i 
        ? `https://covers.openlibrary.org/b/id/${book.cover_i}-L.jpg`
        : 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=300',
      infoLink: `https://openlibrary.org${book.key}`,
      previewLink: `https://openlibrary.org${book.key}`
    }));
  } catch (error) {
    console.error('Error searching Open Library:', error);
    return [];
  }
};

// Get books by category (legacy function)
export const getBooksByCategory = async (category: string): Promise<Book[]> => {
  return await getBooksByTopic(category);
};

// Get books by topic
export const getBooksByTopic = async (topic: string): Promise<Book[]> => {
  const searchTerms = bookTopics[topic as keyof typeof bookTopics] || [topic];
  const randomTerm = searchTerms[Math.floor(Math.random() * searchTerms.length)];
  
  // Also include some popular books from the topic
  const popularBooksInTopic = popularBooks[topic as keyof typeof popularBooks] || [];
  
  if (popularBooksInTopic.length > 0) {
    const randomPopularBook = popularBooksInTopic[Math.floor(Math.random() * popularBooksInTopic.length)];
    return await searchBooks(randomPopularBook);
  }
  
  return await searchBooks(randomTerm);
};

// Get trending/popular books
export const getTrendingBooks = async (): Promise<Book[]> => {
  const trendingQueries = [
    'bestseller 2024', 'popular fiction', 'award winning books', 
    'new releases', 'book club picks', 'must read books'
  ];
  
  const randomQuery = trendingQueries[Math.floor(Math.random() * trendingQueries.length)];
  return await searchBooks(randomQuery, 15);
};

// Get book recommendations based on mood (legacy function)
export const getBooksByMood = async (mood: string): Promise<Book[]> => {
  // Map old moods to new topics
  const moodToTopic = {
    'Happy': 'Self Development',
    'Sad': 'Philosophy',
    'Excited': 'Fantasy Fiction',
    'Relaxed': 'Travel & Adventure',
    'Curious': 'Science & Nature',
    'Romantic': 'Romance',
    'Inspired': 'Biography',
    'Thoughtful': 'Philosophy'
  };
  
  const topic = moodToTopic[mood as keyof typeof moodToTopic] || 'Self Development';
  return await getBooksByTopic(topic);
};

// Generate reading recommendation based on book
export const generateReadingTip = (book: Book, topic?: string): string => {
  const tips = [
    `This ${book.pageCount ? `${book.pageCount}-page` : ''} book is perfect for ${topic ? `${topic.toLowerCase()} enthusiasts` : 'a great reading session'}!`,
    `With an average rating of ${book.averageRating || 'high praise'}, this book has captivated readers worldwide.`,
    `Published in ${book.publishedDate?.split('-')[0] || 'recent years'}, this ${book.categories?.[0]?.toLowerCase() || 'compelling'} read offers deep insights.`,
    `Join the ${book.ratingsCount || 'many'} readers who have discovered the magic of this incredible story.`,
    `This book perfectly captures the essence of ${book.categories?.[0]?.toLowerCase() || 'great literature'} and will keep you engaged from start to finish.`,
    `A must-read that combines excellent storytelling with profound themes - exactly what you need for your ${topic?.toLowerCase() || 'reading'} journey!`
  ];
  
  return tips[Math.floor(Math.random() * tips.length)];
};

// Format book description for display
export const formatDescription = (description: string, maxLength: number = 200): string => {
  if (!description) return 'No description available.';
  
  // Remove HTML tags
  const cleanDescription = description.replace(/<[^>]*>/g, '');
  
  if (cleanDescription.length <= maxLength) return cleanDescription;
  
  const truncated = cleanDescription.substring(0, maxLength);
  const lastSpace = truncated.lastIndexOf(' ');
  
  return lastSpace > 0 ? truncated.substring(0, lastSpace) + '...' : truncated + '...';
};

// Get book details by ID
export const getBookDetails = async (bookId: string): Promise<Book | null> => {
  try {
    const response = await fetch(
      `${GOOGLE_BOOKS_BASE_URL}/${bookId}?key=${GOOGLE_BOOKS_API_KEY}`
    );
    
    if (!response.ok) {
      console.warn('Failed to fetch book details from Google Books');
      return null;
    }
    
    const item = await response.json();
    
    return {
      id: item.id,
      title: item.volumeInfo.title || 'Unknown Title',
      authors: item.volumeInfo.authors || ['Unknown Author'],
      description: item.volumeInfo.description,
      publishedDate: item.volumeInfo.publishedDate,
      pageCount: item.volumeInfo.pageCount,
      categories: item.volumeInfo.categories,
      averageRating: item.volumeInfo.averageRating,
      ratingsCount: item.volumeInfo.ratingsCount,
      thumbnail: item.volumeInfo.imageLinks?.thumbnail?.replace('http:', 'https:'),
      previewLink: item.volumeInfo.previewLink,
      infoLink: item.volumeInfo.infoLink,
      isbn: item.volumeInfo.industryIdentifiers?.[0]?.identifier
    };
  } catch (error) {
    console.error('Error fetching book details:', error);
    return null;
  }
};