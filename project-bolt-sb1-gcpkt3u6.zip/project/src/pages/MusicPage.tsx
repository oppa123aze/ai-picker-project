import React, { useState, useEffect } from 'react';
import { Music, Headphones, Play, ExternalLink, X, Loader, Volume2 } from 'lucide-react';
import { getMusicByMood, getPopularPodcasts, formatDuration, openInSpotify, SpotifyTrack, SpotifyPodcast } from '../services/spotifyService';

const musicMoods = [
  { name: 'Happy', emoji: '😊', color: 'from-yellow-400 to-orange-400' },
  { name: 'Sad', emoji: '😢', color: 'from-blue-400 to-indigo-400' },
  { name: 'Energetic', emoji: '⚡', color: 'from-red-400 to-pink-400' },
  { name: 'Relaxed', emoji: '😌', color: 'from-green-400 to-teal-400' },
  { name: 'Focused', emoji: '🎯', color: 'from-purple-400 to-violet-400' },
  { name: 'Romantic', emoji: '💕', color: 'from-pink-400 to-rose-400' }
];

const MusicPage = () => {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [selectedTrack, setSelectedTrack] = useState<SpotifyTrack | null>(null);
  const [tracks, setTracks] = useState<SpotifyTrack[]>([]);
  const [podcasts, setPodcasts] = useState<SpotifyPodcast[]>([]);
  const [loading, setLoading] = useState(false);
  const [showPodcasts, setShowPodcasts] = useState(false);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);

  useEffect(() => {
    loadPodcasts();
  }, []);

  const loadPodcasts = async () => {
    try {
      const podcastData = await getPopularPodcasts();
      setPodcasts(podcastData);
    } catch (error) {
      console.error('Error loading podcasts:', error);
    }
  };

  const loadMusicByMood = async (mood: string) => {
    setLoading(true);
    try {
      const musicData = await getMusicByMood(mood);
      setTracks(musicData);
      setCurrentTrackIndex(0);
    } catch (error) {
      console.error('Error loading music:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedMood) {
      loadMusicByMood(selectedMood);
    }
  }, [selectedMood]);

  const handleNext = () => {
    setCurrentTrackIndex((prev) => (prev + 1) % tracks.length);
  };

  const resetSelection = () => {
    setSelectedMood(null);
    setSelectedTrack(null);
    setTracks([]);
    setShowPodcasts(false);
    setCurrentTrackIndex(0);
  };

  const handleSpotifyRedirect = (url: string) => {
    // Show a polite message before redirecting
    const message = "We'll redirect you to Spotify to listen to the full version. Enjoy your music! 🎵";
    if (window.confirm(message)) {
      openInSpotify(url);
    }
  };

  if (selectedTrack) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedTrack(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to music
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden">
          <div className="md:flex">
            <div className="md:w-2/5">
              <img
                src={selectedTrack.album.images[0]?.url || 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400'}
                alt={selectedTrack.album.name}
                className="w-full h-96 md:h-full object-cover"
              />
            </div>
            <div className="md:w-3/5 p-8">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{selectedTrack.name}</h1>
                  <p className="text-xl text-blue-300 mb-2">{selectedTrack.artists[0]?.name}</p>
                  <p className="text-white/70">{selectedTrack.album.name}</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 text-white/70 mb-6">
                <span className="flex items-center">
                  <Volume2 className="h-4 w-4 mr-1" />
                  {formatDuration(selectedTrack.duration_ms)}
                </span>
              </div>

              <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl p-4 mb-6 border border-green-500/30">
                <h3 className="text-green-300 font-semibold mb-2">🎵 Perfect for your {selectedMood?.toLowerCase()} mood!</h3>
                <p className="text-green-300 text-sm">
                  This track captures exactly the vibe you're looking for. The perfect soundtrack for your current mood.
                </p>
              </div>

              <div className="space-y-4">
                <button 
                  onClick={() => handleSpotifyRedirect(selectedTrack.external_urls.spotify)}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center"
                >
                  <ExternalLink className="h-5 w-5 mr-2" />
                  Listen on Spotify
                </button>
                
                <p className="text-center text-white/60 text-sm">
                  Full version available on Spotify. We'll redirect you there to enjoy the complete experience! 🎧
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (showPodcasts) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setShowPodcasts(false)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to music options
        </button>

        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Popular Podcasts</h2>
          <p className="text-white/70">Discover engaging conversations and stories</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {podcasts.map((podcast) => (
            <div
              key={podcast.id}
              className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden hover:bg-white/20 transition-all transform hover:scale-105"
            >
              <img
                src={podcast.images[0]?.url || 'https://images.pexels.com/photos/7045617/pexels-photo-7045617.jpeg?auto=compress&cs=tinysrgb&w=300'}
                alt={podcast.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{podcast.name}</h3>
                <p className="text-blue-300 text-sm mb-2">by {podcast.publisher}</p>
                <p className="text-white/70 text-sm mb-4 line-clamp-3">{podcast.description}</p>
                
                <button 
                  onClick={() => handleSpotifyRedirect(podcast.external_urls.spotify)}
                  className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 text-white py-2 px-4 rounded-xl font-semibold hover:from-purple-600 hover:to-indigo-600 transition-all flex items-center justify-center"
                >
                  <Headphones className="h-4 w-4 mr-2" />
                  Listen on Spotify
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (selectedMood) {
    if (loading) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Change mood
          </button>

          <div className="text-center py-20">
            <Loader className="h-12 w-12 text-green-400 animate-spin mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Finding Perfect Music</h2>
            <p className="text-white/70">Curating the best {selectedMood.toLowerCase()} tracks for you...</p>
          </div>
        </div>
      );
    }

    const currentTrack = tracks[currentTrackIndex];
    if (!currentTrack) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <p className="text-white mb-4">No tracks found for this mood. Try another!</p>
          <button onClick={resetSelection} className="text-blue-300 hover:text-blue-200">
            Go back
          </button>
        </div>
      );
    }

    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={resetSelection}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Change mood
        </button>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            Perfect for your {selectedMood.toLowerCase()} mood
          </h2>
          <p className="text-white/70">Discover music that matches your vibe</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden max-w-2xl mx-auto">
          <img
            src={currentTrack.album.images[0]?.url || 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=500'}
            alt={currentTrack.album.name}
            className="w-full h-80 object-cover"
          />
          
          <div className="p-6">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-white mb-1">{currentTrack.name}</h3>
              <p className="text-xl text-blue-300 mb-1">{currentTrack.artists[0]?.name}</p>
              <p className="text-white/60">{currentTrack.album.name}</p>
            </div>

            <div className="flex justify-center items-center space-x-4 text-white/70 mb-6">
              <span className="flex items-center">
                <Volume2 className="h-4 w-4 mr-1" />
                {formatDuration(currentTrack.duration_ms)}
              </span>
            </div>

            <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl p-4 mb-6 border border-green-500/30">
              <p className="text-green-300 text-sm text-center">
                🎵 This track perfectly captures your {selectedMood.toLowerCase()} energy. Get ready to vibe!
              </p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setSelectedTrack(currentTrack)}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all flex items-center justify-center"
              >
                <Play className="h-5 w-5 mr-2" />
                Play This
              </button>
              <button
                onClick={handleNext}
                className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all"
              >
                Next Track
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-white/60 mt-6">
          {currentTrackIndex + 1} of {tracks.length} suggestions
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          What to <span className="bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">Listen</span>?
        </h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
          Discover music and podcasts that match your mood, powered by Spotify
        </p>
      </div>

      {/* Content Type Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 text-center">
          <Music className="h-12 w-12 text-green-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-3">Music by Mood</h3>
          <p className="text-white/70 mb-6">Find the perfect soundtrack for how you're feeling</p>
        </div>

        <button
          onClick={() => setShowPodcasts(true)}
          className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 text-center hover:bg-white/20 transition-all transform hover:scale-105"
        >
          <Headphones className="h-12 w-12 text-purple-400 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-3">Popular Podcasts</h3>
          <p className="text-white/70 mb-6">Discover engaging conversations and stories</p>
          <div className="text-purple-300">
            Browse Podcasts →
          </div>
        </button>
      </div>

      {/* Music Moods */}
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-4">Choose Your Mood</h2>
        <p className="text-white/70">Select how you're feeling and we'll find the perfect music</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {musicMoods.map((mood) => (
          <button
            key={mood.name}
            onClick={() => setSelectedMood(mood.name)}
            className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
          >
            <div className={`w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-r ${mood.color} flex items-center justify-center text-4xl transform group-hover:scale-110 transition-transform`}>
              {mood.emoji}
            </div>
            <h3 className="text-xl font-bold text-white mb-2 group-hover:text-green-300 transition-colors">
              {mood.name}
            </h3>
          </button>
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-green-500/10 to-blue-500/10 backdrop-blur-md rounded-2xl border border-green-500/20 p-8">
        <h3 className="text-green-300 font-semibold mb-4">🎵 Powered by Spotify</h3>
        <p className="text-white/80 mb-4">
          Our music recommendations are curated to match your exact mood. For the full listening experience, 
          we'll politely redirect you to Spotify where you can enjoy unlimited streaming.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-white/70">
          <div>🎧 Mood-based music curation</div>
          <div>🎙️ Popular podcast recommendations</div>
          <div>🎵 Direct Spotify integration</div>
          <div>⭐ Personalized suggestions</div>
        </div>
      </div>
    </div>
  );
};

export default MusicPage;