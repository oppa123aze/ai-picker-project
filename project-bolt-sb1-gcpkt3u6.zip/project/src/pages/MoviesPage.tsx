import React, { useState, useEffect } from 'react';
import { Star, Clock, Calendar, X, ThumbsUp, ThumbsDown, Loader } from 'lucide-react';
import { searchMoviesByMood, generateAIDescription, getShortPlot, Movie } from '../services/movieService';

const moods = [
  { 
    name: 'Happy', 
    color: 'from-yellow-400 to-orange-400', 
    emoji: '😊',
    keywords: ['comedy', 'feel-good', 'uplifting']
  },
  { 
    name: 'Sad', 
    color: 'from-blue-400 to-indigo-400', 
    emoji: '😢',
    keywords: ['drama', 'emotional', 'touching']
  },
  { 
    name: 'Excited', 
    color: 'from-red-400 to-pink-400', 
    emoji: '🤩',
    keywords: ['action', 'adventure', 'thrilling']
  },
  { 
    name: 'Relaxed', 
    color: 'from-green-400 to-teal-400', 
    emoji: '😌',
    keywords: ['calm', 'peaceful', 'slow-paced']
  },
  { 
    name: 'Curious', 
    color: 'from-purple-400 to-violet-400', 
    emoji: '🤔',
    keywords: ['mystery', 'sci-fi', 'documentary']
  },
  { 
    name: 'Romantic', 
    color: 'from-pink-400 to-rose-400', 
    emoji: '💝',
    keywords: ['romance', 'love story', 'romantic comedy']
  }
];

const MoviesPage = () => {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [currentMovieIndex, setCurrentMovieIndex] = useState(0);
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadMoviesForMood = async (mood: string) => {
    setLoading(true);
    setError(null);
    try {
      const movieResults = await searchMoviesByMood(mood);
      if (movieResults.length > 0) {
        setMovies(movieResults);
        setCurrentMovieIndex(0);
      } else {
        setError('No movies found for this mood. Please try another one!');
      }
    } catch (err) {
      setError('Failed to load movies. Please try again.');
      console.error('Error loading movies:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedMood) {
      loadMoviesForMood(selectedMood);
    }
  }, [selectedMood]);

  const handleNext = () => {
    setCurrentMovieIndex((prev) => (prev + 1) % movies.length);
  };

  const handlePass = () => {
    handleNext();
  };

  const resetSelection = () => {
    setSelectedMood(null);
    setSelectedMovie(null);
    setCurrentMovieIndex(0);
    setMovies([]);
    setError(null);
  };

  const getRatingValue = (movie: Movie): string => {
    if (movie.imdbRating && movie.imdbRating !== 'N/A') {
      return movie.imdbRating;
    }
    if (movie.Ratings && movie.Ratings.length > 0) {
      const imdbRating = movie.Ratings.find(r => r.Source === 'Internet Movie Database');
      if (imdbRating) {
        return imdbRating.Value.split('/')[0];
      }
      return movie.Ratings[0].Value.split('/')[0];
    }
    return 'N/A';
  };

  if (selectedMovie) {
    const aiDescription = generateAIDescription(selectedMovie, selectedMood || '');
    const rating = getRatingValue(selectedMovie);

    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedMovie(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to suggestions
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden">
          <div className="md:flex">
            <div className="md:w-2/5">
              <img
                src={selectedMovie.Poster !== 'N/A' ? selectedMovie.Poster : 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=400'}
                alt={selectedMovie.Title}
                className="w-full h-96 md:h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=400';
                }}
              />
            </div>
            <div className="md:w-3/5 p-8">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{selectedMovie.Title}</h1>
                  <div className="flex items-center space-x-4 text-white/70">
                    <span>{selectedMovie.Year}</span>
                    <span className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {selectedMovie.Runtime}
                    </span>
                    {rating !== 'N/A' && (
                      <span className="flex items-center">
                        <Star className="h-4 w-4 mr-1 text-yellow-400" />
                        {rating}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <p className="text-blue-300 font-semibold mb-2">{selectedMovie.Genre}</p>
              
              {selectedMovie.Director && selectedMovie.Director !== 'N/A' && (
                <p className="text-white/70 mb-2">
                  <span className="font-semibold">Director:</span> {selectedMovie.Director}
                </p>
              )}

              {selectedMovie.Actors && selectedMovie.Actors !== 'N/A' && (
                <p className="text-white/70 mb-4">
                  <span className="font-semibold">Starring:</span> {selectedMovie.Actors}
                </p>
              )}
              
              <div className="mb-6">
                <h3 className="text-white font-semibold mb-2">Plot</h3>
                <p className="text-white/80 leading-relaxed">{getShortPlot(selectedMovie.Plot, 150)}</p>
              </div>

              <div className="mb-6">
                <h3 className="text-white font-semibold mb-2">Why You'll Love It</h3>
                <p className="text-green-300 leading-relaxed">{aiDescription}</p>
              </div>

              {selectedMovie.Awards && selectedMovie.Awards !== 'N/A' && (
                <div className="mb-6">
                  <h3 className="text-white font-semibold mb-2">Awards</h3>
                  <p className="text-yellow-300 text-sm">{getShortPlot(selectedMovie.Awards, 100)}</p>
                </div>
              )}

              <div className="flex space-x-4">
                <button className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all">
                  Watch Now
                </button>
                <button 
                  onClick={() => setSelectedMovie(null)}
                  className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all"
                >
                  More Options
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (selectedMood) {
    if (loading) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Change mood
          </button>

          <div className="text-center py-20">
            <Loader className="h-12 w-12 text-blue-400 animate-spin mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Finding Perfect Movies</h2>
            <p className="text-white/70">AI is curating the best {selectedMood.toLowerCase()} movies for you...</p>
          </div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors mx-auto"
          >
            <X className="h-5 w-5 mr-2" />
            Change mood
          </button>
          
          <div className="bg-red-500/20 border border-red-500/30 rounded-xl p-6 mb-6">
            <p className="text-red-300 mb-4">{error}</p>
            <button 
              onClick={() => loadMoviesForMood(selectedMood)}
              className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-lg transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      );
    }

    const currentMovie = movies[currentMovieIndex];
    if (!currentMovie) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <p className="text-white">No movies available. Please try another mood!</p>
          <button onClick={resetSelection} className="mt-4 text-blue-300 hover:text-blue-200">
            Go back
          </button>
        </div>
      );
    }

    const aiDescription = generateAIDescription(currentMovie, selectedMood);
    const rating = getRatingValue(currentMovie);

    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={resetSelection}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Change mood
        </button>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            Perfect for your {selectedMood.toLowerCase()} mood
          </h2>
          <p className="text-white/70">Swipe through our AI-curated suggestions</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden max-w-3xl mx-auto">
          <img
            src={currentMovie.Poster !== 'N/A' ? currentMovie.Poster : 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=500'}
            alt={currentMovie.Title}
            className="w-full h-80 object-cover"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = 'https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=500';
            }}
          />
          
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-2xl font-bold text-white">{currentMovie.Title}</h3>
              {rating !== 'N/A' && (
                <div className="flex items-center text-yellow-400">
                  <Star className="h-5 w-5 mr-1" />
                  <span className="font-semibold">{rating}</span>
                </div>
              )}
            </div>

            <div className="flex items-center space-x-4 text-white/70 mb-4">
              <span>{currentMovie.Year}</span>
              <span>{currentMovie.Runtime}</span>
              <span>{currentMovie.Genre}</span>
            </div>

            <p className="text-white/80 mb-4 leading-relaxed">{getShortPlot(currentMovie.Plot, 100)}</p>
            
            <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl p-4 mb-6 border border-green-500/30">
              <p className="text-green-300 text-sm leading-relaxed">{aiDescription}</p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setSelectedMovie(currentMovie)}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all flex items-center justify-center"
              >
                <ThumbsUp className="h-5 w-5 mr-2" />
                Watch This
              </button>
              <button
                onClick={handlePass}
                className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all flex items-center justify-center"
              >
                <ThumbsDown className="h-5 w-5 mr-2" />
                Pass
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-white/60 mt-6">
          {currentMovieIndex + 1} of {movies.length} suggestions
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          What's Your <span className="bg-gradient-to-r from-red-400 to-pink-400 bg-clip-text text-transparent">Mood</span>?
        </h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto">
          Let AI suggest the perfect movie based on how you're feeling right now
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {moods.map((mood) => (
          <button
            key={mood.name}
            onClick={() => setSelectedMood(mood.name)}
            className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
          >
            <div className={`w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-r ${mood.color} flex items-center justify-center text-4xl transform group-hover:scale-110 transition-transform`}>
              {mood.emoji}
            </div>
            <h3 className="text-xl font-bold text-white mb-2 group-hover:text-blue-300 transition-colors">
              {mood.name}
            </h3>
            <p className="text-white/60 text-sm">
              {mood.keywords.join(', ')}
            </p>
          </button>
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 backdrop-blur-md rounded-2xl border border-purple-500/20 p-8">
        <h3 className="text-white font-semibold mb-4">🎬 Massive Movie Database</h3>
        <p className="text-white/80 mb-4">
          Our AI analyzes thousands of movies from OMDb to find the perfect match for your mood. 
          Each mood now contains 15+ carefully curated films with detailed information and personalized recommendations.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-white/70">
          <div>✨ 15+ movies per mood category</div>
          <div>🎭 Real IMDb ratings & reviews</div>
          <div>🎪 Detailed cast & crew info</div>
          <div>🏆 Awards & recognition data</div>
        </div>
      </div>
    </div>
  );
};

export default MoviesPage;