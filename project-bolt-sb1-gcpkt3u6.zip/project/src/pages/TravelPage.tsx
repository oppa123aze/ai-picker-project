import React, { useState, useEffect } from 'react';
import { Plane, MapPin, Star, Clock, DollarSign, X, ThumbsUp, ThumbsDown, Loader, ExternalLink, Calendar } from 'lucide-react';

const travelMoods = [
  { name: 'Adventure', emoji: '🏔️', color: 'from-orange-500 to-red-500' },
  { name: 'Relaxation', emoji: '🏖️', color: 'from-blue-500 to-cyan-500' },
  { name: 'Culture', emoji: '🏛️', color: 'from-purple-500 to-indigo-500' },
  { name: 'Romance', emoji: '💕', color: 'from-pink-500 to-rose-500' },
  { name: 'Family Fun', emoji: '👨‍👩‍👧‍👦', color: 'from-green-500 to-emerald-500' },
  { name: 'Solo Journey', emoji: '🎒', color: 'from-yellow-500 to-orange-500' },
  { name: 'City Break', emoji: '🏙️', color: 'from-gray-500 to-slate-500' },
  { name: 'Nature', emoji: '🌲', color: 'from-green-600 to-teal-600' }
];

const budgetRanges = [
  { name: 'Budget', range: 'Under $1000', emoji: '💰', color: 'from-green-500 to-emerald-500' },
  { name: 'Mid-Range', range: '$1000-3000', emoji: '💳', color: 'from-blue-500 to-indigo-500' },
  { name: 'Luxury', range: '$3000+', emoji: '💎', color: 'from-purple-500 to-pink-500' }
];

interface Destination {
  name: string;
  country: string;
  description: string;
  bestTime: string;
  estimatedCost: string;
  highlights: string[];
  whyPerfect: string;
  flightInfo?: {
    duration: string;
    averagePrice: string;
  };
}

const TravelPage = () => {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [selectedBudget, setSelectedBudget] = useState<string | null>(null);
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [currentDestinationIndex, setCurrentDestinationIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [duration, setDuration] = useState<string>('');
  const [fromLocation, setFromLocation] = useState<string>('');

  const generateDestinations = async (mood: string, budget: string) => {
    setLoading(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const suggestions = generateSmartDestinations(mood, budget, duration, fromLocation);
      setDestinations(suggestions);
      setCurrentDestinationIndex(0);
    } catch (error) {
      console.error('Error generating destinations:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateSmartDestinations = (mood: string, budget: string, duration: string, from: string): Destination[] => {
    const destinationDatabase = {
      'Adventure-Budget': [
        {
          name: 'Banff National Park',
          country: 'Canada',
          description: 'Stunning mountain landscapes with hiking, skiing, and wildlife viewing',
          bestTime: 'June-September for hiking, December-March for skiing',
          estimatedCost: '$600-900',
          highlights: ['Lake Louise', 'Moraine Lake', 'Icefields Parkway', 'Wildlife spotting'],
          whyPerfect: 'Incredible natural beauty with affordable outdoor activities and camping options',
          flightInfo: { duration: '4-8 hours', averagePrice: '$300-600' }
        },
        {
          name: 'Costa Rica',
          country: 'Costa Rica',
          description: 'Adventure paradise with volcanoes, rainforests, and beaches',
          bestTime: 'December-April (dry season)',
          estimatedCost: '$700-1000',
          highlights: ['Zip-lining', 'Volcano hiking', 'Wildlife tours', 'Beach time'],
          whyPerfect: 'Perfect mix of adventure activities with budget-friendly accommodations',
          flightInfo: { duration: '5-9 hours', averagePrice: '$400-700' }
        }
      ],
      'Relaxation-Luxury': [
        {
          name: 'Maldives',
          country: 'Maldives',
          description: 'Overwater bungalows and pristine beaches in tropical paradise',
          bestTime: 'November-April',
          estimatedCost: '$4000-8000',
          highlights: ['Overwater villas', 'Spa treatments', 'Snorkeling', 'Fine dining'],
          whyPerfect: 'Ultimate luxury relaxation with world-class resorts and pristine waters',
          flightInfo: { duration: '12-20 hours', averagePrice: '$1200-2500' }
        },
        {
          name: 'Santorini',
          country: 'Greece',
          description: 'Iconic white buildings, stunning sunsets, and luxury resorts',
          bestTime: 'April-October',
          estimatedCost: '$3000-5000',
          highlights: ['Sunset views', 'Wine tasting', 'Luxury hotels', 'Volcanic beaches'],
          whyPerfect: 'Romantic luxury destination with breathtaking views and world-class amenities',
          flightInfo: { duration: '8-15 hours', averagePrice: '$800-1500' }
        }
      ],
      'Culture-Mid-Range': [
        {
          name: 'Kyoto',
          country: 'Japan',
          description: 'Ancient temples, traditional culture, and beautiful gardens',
          bestTime: 'March-May, September-November',
          estimatedCost: '$1500-2500',
          highlights: ['Bamboo forests', 'Temple visits', 'Traditional ryokans', 'Tea ceremonies'],
          whyPerfect: 'Rich cultural heritage with excellent mid-range accommodations and experiences',
          flightInfo: { duration: '10-16 hours', averagePrice: '$700-1200' }
        },
        {
          name: 'Prague',
          country: 'Czech Republic',
          description: 'Medieval architecture, rich history, and vibrant cultural scene',
          bestTime: 'April-October',
          estimatedCost: '$1200-2000',
          highlights: ['Prague Castle', 'Charles Bridge', 'Old Town Square', 'Beer culture'],
          whyPerfect: 'Stunning architecture and culture at very reasonable prices',
          flightInfo: { duration: '6-12 hours', averagePrice: '$500-900' }
        }
      ]
    };

    // Generate key based on mood and budget
    const key = `${mood}-${budget}`;
    let baseDestinations = destinationDatabase[key as keyof typeof destinationDatabase];
    
    // Fallback destinations if specific combination not found
    if (!baseDestinations) {
      baseDestinations = [
        {
          name: 'Barcelona',
          country: 'Spain',
          description: 'Vibrant city with stunning architecture, beaches, and culture',
          bestTime: 'April-October',
          estimatedCost: '$1000-2000',
          highlights: ['Sagrada Familia', 'Park Güell', 'Beach time', 'Tapas tours'],
          whyPerfect: `Perfect blend of ${mood.toLowerCase()} activities with great value for money`,
          flightInfo: { duration: '6-12 hours', averagePrice: '$400-800' }
        },
        {
          name: 'Thailand',
          country: 'Thailand',
          description: 'Exotic culture, beautiful beaches, and incredible food',
          bestTime: 'November-March',
          estimatedCost: '$800-1500',
          highlights: ['Temple visits', 'Island hopping', 'Street food', 'Massage therapy'],
          whyPerfect: `Offers amazing ${mood.toLowerCase()} experiences at excellent value`,
          flightInfo: { duration: '12-20 hours', averagePrice: '$600-1200' }
        }
      ];
    }

    // Add some additional variety
    const additionalDestinations = [
      {
        name: 'Iceland',
        country: 'Iceland',
        description: 'Dramatic landscapes with geysers, waterfalls, and Northern Lights',
        bestTime: 'June-August for hiking, September-March for Northern Lights',
        estimatedCost: '$1500-3000',
        highlights: ['Blue Lagoon', 'Golden Circle', 'Northern Lights', 'Glacier tours'],
        whyPerfect: `Unique natural wonders perfect for ${mood.toLowerCase()} seekers`,
        flightInfo: { duration: '5-8 hours', averagePrice: '$400-800' }
      },
      {
        name: 'New Zealand',
        country: 'New Zealand',
        description: 'Breathtaking landscapes and outdoor adventures',
        bestTime: 'October-April',
        estimatedCost: '$2000-4000',
        highlights: ['Milford Sound', 'Hobbiton', 'Adventure sports', 'Wine regions'],
        whyPerfect: `Adventure paradise with stunning scenery for ${mood.toLowerCase()} travelers`,
        flightInfo: { duration: '12-24 hours', averagePrice: '$1000-2000' }
      }
    ];

    return [...baseDestinations, ...additionalDestinations].slice(0, 5);
  };

  useEffect(() => {
    if (selectedMood && selectedBudget) {
      generateDestinations(selectedMood, selectedBudget);
    }
  }, [selectedMood, selectedBudget]);

  const handleNext = () => {
    setCurrentDestinationIndex((prev) => (prev + 1) % destinations.length);
  };

  const resetSelection = () => {
    setSelectedMood(null);
    setSelectedBudget(null);
    setSelectedDestination(null);
    setDestinations([]);
    setCurrentDestinationIndex(0);
    setDuration('');
    setFromLocation('');
  };

  if (selectedDestination) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedDestination(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to destinations
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">{selectedDestination.name}</h1>
              <p className="text-xl text-blue-300 mb-2">{selectedDestination.country}</p>
              <div className="flex items-center space-x-4 text-white/70">
                <span className="bg-green-500/20 text-green-300 px-3 py-1 rounded-full text-sm">
                  {selectedDestination.estimatedCost}
                </span>
                {selectedDestination.flightInfo && (
                  <span className="bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full text-sm">
                    {selectedDestination.flightInfo.duration} flight
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-white font-semibold mb-2">Description</h3>
            <p className="text-white/80 mb-4">{selectedDestination.description}</p>
          </div>

          <div className="mb-6">
            <h3 className="text-white font-semibold mb-3">Top Highlights</h3>
            <div className="grid grid-cols-2 gap-2">
              {selectedDestination.highlights.map((highlight, index) => (
                <div key={index} className="bg-white/5 rounded-lg px-3 py-2 text-white/80 text-sm">
                  ✨ {highlight}
                </div>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-white font-semibold mb-2">Best Time to Visit</h3>
            <p className="text-orange-300">{selectedDestination.bestTime}</p>
          </div>

          <div className="bg-gradient-to-r from-teal-500/20 to-green-500/20 rounded-xl p-4 mb-6 border border-teal-500/30">
            <h3 className="text-teal-300 font-semibold mb-2">✈️ Why This Destination?</h3>
            <p className="text-teal-300 text-sm">{selectedDestination.whyPerfect}</p>
          </div>

          {selectedDestination.flightInfo && (
            <div className="mb-6">
              <h3 className="text-white font-semibold mb-2">Flight Information</h3>
              <div className="flex space-x-4 text-sm">
                <span className="text-blue-300">Duration: {selectedDestination.flightInfo.duration}</span>
                <span className="text-green-300">Average Price: {selectedDestination.flightInfo.averagePrice}</span>
              </div>
            </div>
          )}

          <div className="flex space-x-4">
            <button className="flex-1 bg-gradient-to-r from-teal-500 to-green-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-teal-600 hover:to-green-600 transition-all flex items-center justify-center">
              <ExternalLink className="h-5 w-5 mr-2" />
              Book Trip
            </button>
            <button 
              onClick={() => setSelectedDestination(null)}
              className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all"
            >
              More Destinations
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (selectedMood && selectedBudget) {
    if (loading) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Start over
          </button>

          <div className="text-center py-20">
            <Loader className="h-12 w-12 text-teal-400 animate-spin mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Finding Perfect Destinations</h2>
            <p className="text-white/70">AI is curating the best {selectedMood.toLowerCase()} destinations for your budget...</p>
          </div>
        </div>
      );
    }

    const currentDestination = destinations[currentDestinationIndex];
    if (!currentDestination) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <p className="text-white mb-4">No destinations found. Try different preferences!</p>
          <button onClick={resetSelection} className="text-blue-300 hover:text-blue-200">
            Start over
          </button>
        </div>
      );
    }

    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={resetSelection}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Start over
        </button>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            Perfect {selectedMood} Destination
          </h2>
          <p className="text-white/70">AI-curated travel suggestions within your budget</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden max-w-2xl mx-auto">
          <div className="p-6">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-white mb-2">{currentDestination.name}</h3>
              <p className="text-xl text-blue-300 mb-3">{currentDestination.country}</p>
              <div className="flex justify-center items-center space-x-3 mb-3">
                <span className="bg-green-500/20 text-green-300 px-3 py-1 rounded-full text-sm">
                  {currentDestination.estimatedCost}
                </span>
                {currentDestination.flightInfo && (
                  <span className="bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full text-sm">
                    {currentDestination.flightInfo.duration}
                  </span>
                )}
              </div>
            </div>

            <p className="text-white/80 mb-4 text-center">{currentDestination.description}</p>

            <div className="mb-4">
              <h4 className="text-white font-semibold mb-2 text-center">Highlights</h4>
              <div className="flex flex-wrap justify-center gap-2">
                {currentDestination.highlights.slice(0, 3).map((highlight, index) => (
                  <span key={index} className="bg-teal-500/20 text-teal-300 px-2 py-1 rounded-full text-xs">
                    {highlight}
                  </span>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-r from-teal-500/20 to-green-500/20 rounded-xl p-4 mb-6 border border-teal-500/30">
              <p className="text-teal-300 text-sm text-center">{currentDestination.whyPerfect}</p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setSelectedDestination(currentDestination)}
                className="flex-1 bg-gradient-to-r from-teal-500 to-green-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-teal-600 hover:to-green-600 transition-all flex items-center justify-center"
              >
                <ThumbsUp className="h-5 w-5 mr-2" />
                Book This!
              </button>
              <button
                onClick={handleNext}
                className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all flex items-center justify-center"
              >
                <ThumbsDown className="h-5 w-5 mr-2" />
                Next Option
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-white/60 mt-6">
          {currentDestinationIndex + 1} of {destinations.length} suggestions
        </p>
      </div>
    );
  }

  if (selectedMood) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedMood(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Change travel mood
        </button>

        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white mb-4">What's your budget?</h2>
          <p className="text-white/70">Choose your budget range for personalized destination suggestions</p>
        </div>

        {/* Optional travel preferences */}
        <div className="max-w-2xl mx-auto mb-8 space-y-4">
          <div>
            <label className="block text-white font-semibold mb-2">Trip Duration (optional)</label>
            <input
              type="text"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              placeholder="e.g., 1 week, 10 days, 2 weeks"
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white placeholder-white/50"
            />
          </div>
          <div>
            <label className="block text-white font-semibold mb-2">Departing from (optional)</label>
            <input
              type="text"
              value={fromLocation}
              onChange={(e) => setFromLocation(e.target.value)}
              placeholder="e.g., New York, London, Tokyo"
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white placeholder-white/50"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {budgetRanges.map((budget) => (
            <button
              key={budget.name}
              onClick={() => setSelectedBudget(budget.name)}
              className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
            >
              <div className={`w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-r ${budget.color} flex items-center justify-center text-3xl transform group-hover:scale-110 transition-transform`}>
                {budget.emoji}
              </div>
              <h3 className="text-xl font-bold text-white mb-2 group-hover:text-teal-300 transition-colors">
                {budget.name}
              </h3>
              <p className="text-white/70">{budget.range}</p>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          Where to <span className="bg-gradient-to-r from-teal-400 to-green-400 bg-clip-text text-transparent">Go</span>?
        </h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto">
          AI-powered travel recommendations based on your mood and preferences
        </p>
      </div>

      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-4">What kind of trip are you craving?</h2>
        <p className="text-white/70">Choose your travel mood to get personalized destination suggestions</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {travelMoods.map((mood) => (
          <button
            key={mood.name}
            onClick={() => setSelectedMood(mood.name)}
            className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
          >
            <div className={`w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-r ${mood.color} flex items-center justify-center text-3xl transform group-hover:scale-110 transition-transform`}>
              {mood.emoji}
            </div>
            <h3 className="text-lg font-bold text-white group-hover:text-teal-300 transition-colors">
              {mood.name}
            </h3>
          </button>
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-teal-500/10 to-green-500/10 backdrop-blur-md rounded-2xl border border-teal-500/20 p-8">
        <h3 className="text-teal-300 font-semibold mb-4">✈️ Smart Travel Planning</h3>
        <p className="text-white/80 mb-4">
          Our AI analyzes your travel preferences, budget, and mood to suggest destinations that perfectly match 
          what you're looking for. Get personalized recommendations with flight information and travel tips.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-white/70">
          <div>🎯 Mood-based destination matching</div>
          <div>💰 Budget-conscious travel options</div>
          <div>✈️ Flight duration and pricing estimates</div>
          <div>📅 Best time to visit recommendations</div>
        </div>
      </div>
    </div>
  );
};

export default TravelPage;