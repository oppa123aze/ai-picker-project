import React, { useState, useEffect } from 'react';
import { Book, Star, Calendar, Users, X, ThumbsUp, ThumbsDown, Search, BookOpen, Loader, ExternalLink } from 'lucide-react';
import { 
  searchBooks, 
  getBooksByCategory, 
  getBooksByTopic, 
  getTrendingBooks, 
  generateReadingTip, 
  formatDescription,
  Book as BookType 
} from '../services/booksService';

const bookTopics = [
  { name: 'Business', emoji: '💼', color: 'from-blue-500 to-indigo-500', description: 'Entrepreneurship, leadership, and success strategies' },
  { name: 'Philosophy', emoji: '🤔', color: 'from-purple-500 to-violet-500', description: 'Deep thinking, wisdom, and life\'s big questions' },
  { name: 'Self Development', emoji: '🌱', color: 'from-green-500 to-emerald-500', description: 'Personal growth, habits, and self-improvement' },
  { name: 'Stories for Kids', emoji: '🧸', color: 'from-yellow-500 to-orange-500', description: 'Children\'s books, fairy tales, and educational stories' },
  { name: 'Fantasy Fiction', emoji: '🐉', color: 'from-purple-600 to-pink-500', description: 'Magic, dragons, and imaginary worlds' },
  { name: 'Historical', emoji: '🏛️', color: 'from-amber-500 to-orange-500', description: 'History, biographies, and historical fiction' },
  { name: 'Science Fiction', emoji: '🚀', color: 'from-cyan-500 to-blue-500', description: 'Future worlds, technology, and space exploration' },
  { name: 'Romance', emoji: '💕', color: 'from-pink-500 to-rose-500', description: 'Love stories, romantic fiction, and relationships' },
  { name: 'Mystery & Thriller', emoji: '🔍', color: 'from-gray-600 to-slate-700', description: 'Crime, detective stories, and suspense' },
  { name: 'Health & Fitness', emoji: '💪', color: 'from-red-500 to-orange-500', description: 'Wellness, nutrition, and physical fitness' },
  { name: 'Technology', emoji: '💻', color: 'from-indigo-500 to-purple-500', description: 'Programming, AI, and digital innovation' },
  { name: 'Psychology', emoji: '🧠', color: 'from-teal-500 to-green-500', description: 'Human behavior, mental health, and mind science' },
  { name: 'Biography', emoji: '👤', color: 'from-orange-500 to-red-500', description: 'Life stories of inspiring people' },
  { name: 'Science & Nature', emoji: '🔬', color: 'from-emerald-500 to-teal-500', description: 'Scientific discoveries and natural world' },
  { name: 'Art & Creativity', emoji: '🎨', color: 'from-pink-400 to-purple-400', description: 'Creative expression, design, and artistic inspiration' },
  { name: 'Travel & Adventure', emoji: '🌍', color: 'from-blue-400 to-cyan-400', description: 'Exploration, travel guides, and adventure stories' }
];

const BooksPage = () => {
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [selectedBook, setSelectedBook] = useState<BookType | null>(null);
  const [books, setBooks] = useState<BookType[]>([]);
  const [currentBookIndex, setCurrentBookIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showTrending, setShowTrending] = useState(false);

  const loadBooksByTopic = async (topic: string) => {
    setLoading(true);
    try {
      const results = await getBooksByTopic(topic);
      setBooks(results);
      setCurrentBookIndex(0);
    } catch (error) {
      console.error('Error loading books by topic:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadTrendingBooks = async () => {
    setLoading(true);
    try {
      const results = await getTrendingBooks();
      setBooks(results);
      setCurrentBookIndex(0);
    } catch (error) {
      console.error('Error loading trending books:', error);
    } finally {
      setLoading(false);
    }
  };

  const searchBooksQuery = async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    try {
      const results = await searchBooks(searchQuery);
      setBooks(results);
      setCurrentBookIndex(0);
    } catch (error) {
      console.error('Error searching books:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedTopic) {
      loadBooksByTopic(selectedTopic);
    }
  }, [selectedTopic]);

  useEffect(() => {
    if (showTrending) {
      loadTrendingBooks();
    }
  }, [showTrending]);

  const handleNext = () => {
    setCurrentBookIndex((prev) => (prev + 1) % books.length);
  };

  const resetSelection = () => {
    setSelectedTopic(null);
    setSelectedBook(null);
    setBooks([]);
    setCurrentBookIndex(0);
    setShowTrending(false);
    setSearchQuery('');
  };

  const openBookLink = (url: string) => {
    window.open(url, '_blank');
  };

  if (selectedBook) {
    const readingTip = generateReadingTip(selectedBook, selectedTopic || 'general');

    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedBook(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to books
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden">
          <div className="md:flex">
            <div className="md:w-2/5">
              <img
                src={selectedBook.thumbnail || 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400'}
                alt={selectedBook.title}
                className="w-full h-96 md:h-full object-cover"
              />
            </div>
            <div className="md:w-3/5 p-8">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{selectedBook.title}</h1>
                  <p className="text-xl text-blue-300 mb-2">by {selectedBook.authors.join(', ')}</p>
                  {selectedBook.publishedDate && (
                    <p className="text-white/70">Published: {selectedBook.publishedDate.split('-')[0]}</p>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-4 text-white/70 mb-6">
                {selectedBook.averageRating && (
                  <span className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 mr-1" />
                    {selectedBook.averageRating.toFixed(1)}
                  </span>
                )}
                {selectedBook.pageCount && (
                  <span className="flex items-center">
                    <BookOpen className="h-4 w-4 mr-1" />
                    {selectedBook.pageCount} pages
                  </span>
                )}
                {selectedBook.ratingsCount && (
                  <span className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    {selectedBook.ratingsCount.toLocaleString()} ratings
                  </span>
                )}
              </div>

              {selectedBook.categories && selectedBook.categories.length > 0 && (
                <div className="mb-4">
                  <div className="flex flex-wrap gap-2">
                    {selectedBook.categories.slice(0, 3).map((category, index) => (
                      <span key={index} className="bg-purple-500/20 text-purple-300 px-3 py-1 rounded-full text-sm">
                        {category}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {selectedBook.description && (
                <div className="mb-6">
                  <h3 className="text-white font-semibold mb-2">Description</h3>
                  <p className="text-white/80 leading-relaxed">{formatDescription(selectedBook.description, 300)}</p>
                </div>
              )}

              <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-xl p-4 mb-6 border border-blue-500/30">
                <h3 className="text-blue-300 font-semibold mb-2">📚 Why You'll Love This Book</h3>
                <p className="text-blue-300 text-sm">{readingTip}</p>
              </div>

              <div className="flex space-x-4">
                {selectedBook.previewLink && (
                  <button 
                    onClick={() => openBookLink(selectedBook.previewLink!)}
                    className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center"
                  >
                    <ExternalLink className="h-5 w-5 mr-2" />
                    Preview Book
                  </button>
                )}
                
                {selectedBook.infoLink && (
                  <button 
                    onClick={() => openBookLink(selectedBook.infoLink!)}
                    className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all flex items-center justify-center"
                  >
                    <BookOpen className="h-5 w-5 mr-2" />
                    More Info
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (selectedTopic || showTrending) {
    if (loading) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Back to topics
          </button>

          <div className="text-center py-20">
            <Loader className="h-12 w-12 text-blue-400 animate-spin mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Finding Perfect Books</h2>
            <p className="text-white/70">
              Searching for {selectedTopic ? `${selectedTopic}` : 'trending'} books...
            </p>
          </div>
        </div>
      );
    }

    const currentBook = books[currentBookIndex];
    if (!currentBook) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <p className="text-white mb-4">No books found. Try another search!</p>
          <button onClick={resetSelection} className="text-blue-300 hover:text-blue-200">
            Go back
          </button>
        </div>
      );
    }

    const readingTip = generateReadingTip(currentBook, selectedTopic || 'trending');

    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={resetSelection}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to topics
        </button>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            {selectedTopic ? `${selectedTopic} Books` : 'Trending Books'}
          </h2>
          <p className="text-white/70">Discover your next great read</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden max-w-2xl mx-auto">
          <img
            src={currentBook.thumbnail || 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=500'}
            alt={currentBook.title}
            className="w-full h-80 object-cover"
          />
          
          <div className="p-6">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-white mb-1">{currentBook.title}</h3>
              <p className="text-xl text-blue-300 mb-1">by {currentBook.authors.join(', ')}</p>
              {currentBook.publishedDate && (
                <p className="text-white/60">{currentBook.publishedDate.split('-')[0]}</p>
              )}
            </div>

            <div className="flex justify-center items-center space-x-4 text-white/70 mb-4">
              {currentBook.averageRating && (
                <span className="flex items-center">
                  <Star className="h-4 w-4 text-yellow-400 mr-1" />
                  {currentBook.averageRating.toFixed(1)}
                </span>
              )}
              {currentBook.pageCount && (
                <span className="flex items-center">
                  <BookOpen className="h-4 w-4 mr-1" />
                  {currentBook.pageCount} pages
                </span>
              )}
            </div>

            {currentBook.description && (
              <p className="text-white/80 mb-4 text-center">{formatDescription(currentBook.description, 120)}</p>
            )}

            <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-xl p-4 mb-6 border border-blue-500/30">
              <p className="text-blue-300 text-sm text-center">{readingTip}</p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setSelectedBook(currentBook)}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all flex items-center justify-center"
              >
                <ThumbsUp className="h-5 w-5 mr-2" />
                Read This
              </button>
              <button
                onClick={handleNext}
                className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all flex items-center justify-center"
              >
                <ThumbsDown className="h-5 w-5 mr-2" />
                Next Book
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-white/60 mt-6">
          {currentBookIndex + 1} of {books.length} suggestions
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          What to <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Read</span>?
        </h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
          Discover your next favorite book with AI-powered recommendations from Google Books and Open Library
        </p>
      </div>

      {/* Search and Browse Options */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Search className="h-6 w-6 text-blue-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for books..."
              className="flex-1 bg-transparent text-white placeholder-white/50 outline-none"
              onKeyPress={(e) => e.key === 'Enter' && searchBooksQuery()}
            />
          </div>
          <button
            onClick={searchBooksQuery}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-xl transition-colors"
          >
            Search Books
          </button>
        </div>

        <button
          onClick={() => setShowTrending(true)}
          className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 text-center hover:bg-white/20 transition-all transform hover:scale-105"
        >
          <Star className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-2">Trending Books</h3>
          <p className="text-sm text-white/70">Popular & award-winning reads</p>
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 text-center">
          <Book className="h-8 w-8 text-purple-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-2">Browse by Topic</h3>
          <p className="text-sm text-white/70">Choose from categories below</p>
        </div>
      </div>

      {/* Book Topics */}
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-4">Choose Your Reading Topic</h2>
        <p className="text-white/70">Find books that match your interests and goals</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {bookTopics.map((topic) => (
          <button
            key={topic.name}
            onClick={() => setSelectedTopic(topic.name)}
            className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 text-left"
          >
            <div className={`w-16 h-16 mb-4 rounded-xl bg-gradient-to-r ${topic.color} flex items-center justify-center text-3xl transform group-hover:scale-110 transition-transform`}>
              {topic.emoji}
            </div>
            
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-blue-300 transition-colors">
              {topic.name}
            </h3>
            
            <p className="text-white/60 text-sm leading-relaxed">
              {topic.description}
            </p>
          </button>
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-blue-500/10 to-purple-500/10 backdrop-blur-md rounded-2xl border border-blue-500/20 p-8">
        <h3 className="text-blue-300 font-semibold mb-4">📚 Powered by Google Books & Open Library</h3>
        <p className="text-white/80 mb-4">
          Our book recommendations come from comprehensive databases including Google Books and Open Library, 
          giving you access to millions of titles with detailed information, ratings, and previews.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-white/70">
          <div>📖 Millions of books from Google Books API</div>
          <div>⭐ Real ratings and reviews</div>
          <div>🔍 Advanced search capabilities</div>
          <div>📱 Direct links to previews and purchase options</div>
        </div>
      </div>
    </div>
  );
};

export default BooksPage;