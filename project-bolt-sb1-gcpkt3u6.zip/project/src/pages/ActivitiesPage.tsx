import React, { useState, useEffect } from 'react';
import { Music, Book, Plane, Gift, Gamepad2, Heart, Car, Briefcase, MapPin, X, Loader, Navigation, Globe, Phone } from 'lucide-react';
import { getCurrentLocation, getActivitiesNearby, formatDistance, Place, UserLocation } from '../services/locationService';

const activityCategories = [
  {
    name: 'Entertainment',
    description: 'Movies, theaters, and live shows',
    icon: Music,
    color: 'from-pink-500 to-rose-500',
    searchType: 'entertainment'
  },
  {
    name: 'Museums & Culture',
    description: 'Museums, galleries, and cultural sites',
    icon: Book,
    color: 'from-amber-500 to-orange-500',
    searchType: 'museums'
  },
  {
    name: 'Parks & Outdoor',
    description: 'Parks, trails, and outdoor activities',
    icon: Car,
    color: 'from-green-500 to-emerald-500',
    searchType: 'parks'
  },
  {
    name: 'Shopping',
    description: 'Malls, markets, and shopping centers',
    icon: Gift,
    color: 'from-violet-500 to-purple-500',
    searchType: 'shopping'
  },
  {
    name: 'Sports & Fitness',
    description: 'Gyms, sports facilities, and activities',
    icon: Gamepad2,
    color: 'from-blue-500 to-indigo-500',
    searchType: 'sports'
  },
  {
    name: 'Nightlife',
    description: 'Bars, clubs, and evening entertainment',
    icon: Heart,
    color: 'from-red-500 to-pink-500',
    searchType: 'nightlife'
  },
  {
    name: 'Learning',
    description: 'Libraries, schools, and educational centers',
    icon: Briefcase,
    color: 'from-green-500 to-emerald-500',
    searchType: 'culture'
  },
  {
    name: 'General Activities',
    description: 'Mixed entertainment and leisure options',
    icon: Plane,
    color: 'from-cyan-500 to-blue-500',
    searchType: 'outdoor'
  }
];

const ActivitiesPage = () => {
  const [selectedCategory, setSelectedCategory] = useState<any>(null);
  const [selectedActivity, setSelectedActivity] = useState<Place | null>(null);
  const [activities, setActivities] = useState<Place[]>([]);
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [loading, setLoading] = useState(false);
  const [locationLoading, setLocationLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    initializeLocation();
  }, []);

  const initializeLocation = async () => {
    try {
      setLocationLoading(true);
      const location = await getCurrentLocation();
      setUserLocation(location);
    } catch (error) {
      console.error('Failed to get location:', error);
      setError('Unable to get your location. Using default location.');
      // Set default location
      setUserLocation({
        lat: 40.7128,
        lon: -74.0060,
        city: 'New York',
        country: 'United States'
      });
    } finally {
      setLocationLoading(false);
    }
  };

  const loadActivities = async (category: any) => {
    if (!userLocation) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const results = await getActivitiesNearby(category.searchType, userLocation.lat, userLocation.lon);
      if (results.length > 0) {
        setActivities(results);
      } else {
        setError(`No ${category.name.toLowerCase()} found nearby. Try expanding your search area.`);
      }
    } catch (error) {
      setError('Failed to load activities. Please try again.');
      console.error('Error loading activities:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedCategory && userLocation) {
      loadActivities(selectedCategory);
    }
  }, [selectedCategory, userLocation]);

  const resetSelection = () => {
    setSelectedCategory(null);
    setSelectedActivity(null);
    setActivities([]);
    setError(null);
  };

  const getDirections = (activity: Place) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${activity.lat},${activity.lon}`;
    window.open(url, '_blank');
  };

  const callPlace = (phone: string) => {
    window.open(`tel:${phone}`, '_self');
  };

  const visitWebsite = (website: string) => {
    window.open(website.startsWith('http') ? website : `https://${website}`, '_blank');
  };

  if (locationLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center py-20">
          <Loader className="h-12 w-12 text-purple-400 animate-spin mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Getting Your Location</h2>
          <p className="text-white/70">Finding the best activities near you...</p>
        </div>
      </div>
    );
  }

  if (selectedActivity) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedActivity(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to activities
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">{selectedActivity.name}</h1>
              <div className="flex items-center text-white/70">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{selectedActivity.distance ? formatDistance(selectedActivity.distance / 1000) : 'Nearby'}</span>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <p className="text-white/80 mb-2">{selectedActivity.formatted}</p>
            {selectedActivity.details?.contact?.phone && (
              <p className="text-blue-300">{selectedActivity.details.contact.phone}</p>
            )}
          </div>

          {selectedActivity.categories.length > 0 && (
            <div className="mb-6">
              <h3 className="text-white font-semibold mb-3">Categories</h3>
              <div className="flex flex-wrap gap-2">
                {selectedActivity.categories.slice(0, 5).map((category, index) => (
                  <span key={index} className="bg-purple-500/20 text-purple-300 px-3 py-1 rounded-full text-sm">
                    {category.split('.').pop()?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="bg-gradient-to-r from-purple-500/20 to-indigo-500/20 rounded-xl p-4 mb-6 border border-purple-500/30">
            <h3 className="text-purple-300 font-semibold mb-2">Activity Info</h3>
            <p className="text-purple-300 text-sm">
              This location is in {selectedActivity.city || 'your area'} and offers great {selectedCategory?.name.toLowerCase()} activities.
              {selectedActivity.distance && ` It's just ${formatDistance(selectedActivity.distance / 1000)} away from your location.`}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button 
              onClick={() => getDirections(selectedActivity)}
              className="bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center"
            >
              <Navigation className="h-5 w-5 mr-2" />
              Get Directions
            </button>
            
            {selectedActivity.details?.contact?.phone && (
              <button 
                onClick={() => callPlace(selectedActivity.details!.contact!.phone!)}
                className="bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all flex items-center justify-center"
              >
                <Phone className="h-5 w-5 mr-2" />
                Call
              </button>
            )}
            
            {selectedActivity.details?.contact?.website && (
              <button 
                onClick={() => visitWebsite(selectedActivity.details!.contact!.website!)}
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all flex items-center justify-center"
              >
                <Globe className="h-5 w-5 mr-2" />
                Website
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (selectedCategory) {
    if (loading) {
      return (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Back to categories
          </button>

          <div className="text-center py-20">
            <Loader className="h-12 w-12 text-purple-400 animate-spin mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Finding {selectedCategory.name}</h2>
            <p className="text-white/70">Searching for the best options near you...</p>
          </div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Back to categories
          </button>

          <div className="text-center">
            <div className="bg-red-500/20 border border-red-500/30 rounded-xl p-6 mb-6">
              <p className="text-red-300 mb-4">{error}</p>
              <button 
                onClick={() => loadActivities(selectedCategory)}
                className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-lg transition-colors"
              >
                Try Again
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={resetSelection}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to categories
        </button>

        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            {selectedCategory.name} Near You
          </h2>
          <div className="flex items-center justify-center text-white/60">
            <MapPin className="h-5 w-5 mr-2" />
            <span>Near {userLocation?.city || 'your location'}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {activities.map((activity, index) => (
            <div
              key={activity.place_id || index}
              className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden cursor-pointer hover:bg-white/20 transition-all transform hover:scale-105"
              onClick={() => setSelectedActivity(activity)}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-xl font-bold text-white">{activity.name}</h3>
                </div>

                <div className="flex items-center mb-3 text-white/70">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{activity.distance ? formatDistance(activity.distance / 1000) : 'Nearby'}</span>
                </div>

                <p className="text-white/60 text-sm mb-4">{activity.formatted}</p>

                <div className="flex flex-wrap gap-1 mb-4">
                  {activity.categories.slice(0, 2).map((category, idx) => (
                    <span key={idx} className="bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full text-xs">
                      {category.split('.').pop()?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                  ))}
                </div>

                <button className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 text-white py-2 px-4 rounded-xl font-semibold hover:from-purple-600 hover:to-indigo-600 transition-all">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          What to <span className="bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">Do</span>?
        </h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto mb-6">
          Discover real activities and places near you with location-based recommendations
        </p>
        <div className="flex items-center justify-center text-white/60">
          <MapPin className="h-5 w-5 mr-2" />
          <span>Activities near {userLocation?.city || 'your location'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activityCategories.map((category) => (
          <button
            key={category.name}
            onClick={() => setSelectedCategory(category)}
            className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 text-left"
          >
            <div className={`w-16 h-16 mb-4 rounded-xl bg-gradient-to-r ${category.color} flex items-center justify-center transform group-hover:scale-110 transition-transform`}>
              <category.icon className="h-8 w-8 text-white" />
            </div>
            
            <h3 className="text-xl font-bold text-white mb-3 group-hover:text-purple-300 transition-colors">
              {category.name}
            </h3>
            
            <p className="text-white/70 leading-relaxed mb-4">
              {category.description}
            </p>
            
            <div className="flex items-center text-purple-300 group-hover:text-purple-200 transition-colors">
              <span className="text-sm font-semibold">Find Nearby</span>
              <svg className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" 
                   fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </button>
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 backdrop-blur-md rounded-2xl border border-purple-500/20 p-8">
        <h3 className="text-white font-semibold mb-4">🎯 Real Location Data</h3>
        <p className="text-white/80 mb-4">
          Our system uses your actual location to find real places and activities nearby. 
          Get accurate addresses, contact information, and directions to make your plans happen.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-white/70">
          <div>✨ Live location-based results</div>
          <div>📍 Real addresses and contact info</div>
          <div>⏰ Distance and navigation data</div>
          <div>🎨 Diverse activity categories</div>
        </div>
      </div>
    </div>
  );
};

export default ActivitiesPage;