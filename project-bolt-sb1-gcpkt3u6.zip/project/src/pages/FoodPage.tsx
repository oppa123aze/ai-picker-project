import React, { useState, useEffect } from 'react';
import { Clock, Users, Heart, Flame, Leaf, X, ThumbsUp, ThumbsDown, Search, ChefHat, Loader } from 'lucide-react';
import { getRecipesByIngredients, searchMealDBRecipes, getRandomMealDBRecipes, generateCookingTip, Recipe } from '../services/recipeService';

const mealTimes = [
  { name: 'Breakfast', icon: '🌅', color: 'from-orange-400 to-yellow-400' },
  { name: 'Lunch', icon: '☀️', color: 'from-blue-400 to-cyan-400' },
  { name: 'Dinner', icon: '🌙', color: 'from-purple-400 to-indigo-400' },
  { name: 'Snacks', icon: '🍿', color: 'from-pink-400 to-rose-400' }
];

const categories = [
  { name: 'Healthy', icon: Leaf, color: 'from-green-400 to-emerald-400' },
  { name: 'Comfort', icon: Heart, color: 'from-red-400 to-pink-400' },
  { name: 'Family', icon: Users, color: 'from-blue-400 to-indigo-400' },
  { name: 'Protein', icon: Flame, color: 'from-orange-400 to-red-400' },
  { name: 'Quick', icon: Clock, color: 'from-purple-400 to-violet-400' }
];

const commonIngredients = [
  'chicken', 'beef', 'pork', 'fish', 'eggs', 'milk', 'cheese', 'butter',
  'rice', 'pasta', 'bread', 'potatoes', 'onions', 'garlic', 'tomatoes',
  'carrots', 'broccoli', 'spinach', 'mushrooms', 'bell peppers',
  'olive oil', 'salt', 'pepper', 'herbs', 'spices'
];

const FoodPage = () => {
  const [selectedMealTime, setSelectedMealTime] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedFood, setSelectedFood] = useState<Recipe | null>(null);
  const [currentFoodIndex, setCurrentFoodIndex] = useState(0);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);
  const [showIngredientSearch, setShowIngredientSearch] = useState(false);
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([]);
  const [customIngredient, setCustomIngredient] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const loadRecipesByCategory = async (mealTime: string, category: string) => {
    setLoading(true);
    try {
      // Create search query based on meal time and category
      const searchTerms = [];
      if (mealTime) searchTerms.push(mealTime.toLowerCase());
      if (category) {
        switch (category) {
          case 'Healthy':
            searchTerms.push('healthy', 'nutritious', 'low calorie');
            break;
          case 'Comfort':
            searchTerms.push('comfort', 'hearty', 'traditional');
            break;
          case 'Family':
            searchTerms.push('family', 'easy', 'kid friendly');
            break;
          case 'Protein':
            searchTerms.push('protein', 'meat', 'high protein');
            break;
          case 'Quick':
            searchTerms.push('quick', 'easy', 'fast');
            break;
        }
      }
      
      const searchTerm = searchTerms[Math.floor(Math.random() * searchTerms.length)] || 'popular';
      const results = await searchMealDBRecipes(searchTerm);
      
      if (results.length === 0) {
        // Fallback to random recipes
        const randomRecipes = await getRandomMealDBRecipes();
        setRecipes(randomRecipes);
      } else {
        setRecipes(results);
      }
    } catch (error) {
      console.error('Error loading recipes:', error);
      // Fallback to random recipes
      const randomRecipes = await getRandomMealDBRecipes();
      setRecipes(randomRecipes);
    } finally {
      setLoading(false);
    }
  };

  const loadRecipesByIngredients = async () => {
    if (selectedIngredients.length === 0) return;
    
    setLoading(true);
    try {
      const results = await getRecipesByIngredients(selectedIngredients);
      setRecipes(results);
    } catch (error) {
      console.error('Error loading recipes by ingredients:', error);
      const randomRecipes = await getRandomMealDBRecipes();
      setRecipes(randomRecipes);
    } finally {
      setLoading(false);
    }
  };

  const searchRecipes = async () => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    try {
      const results = await searchMealDBRecipes(searchQuery);
      setRecipes(results);
    } catch (error) {
      console.error('Error searching recipes:', error);
      const randomRecipes = await getRandomMealDBRecipes();
      setRecipes(randomRecipes);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedMealTime && selectedCategory) {
      loadRecipesByCategory(selectedMealTime, selectedCategory);
    }
  }, [selectedMealTime, selectedCategory]);

  useEffect(() => {
    if (selectedIngredients.length > 0) {
      loadRecipesByIngredients();
    }
  }, [selectedIngredients]);

  const handleNext = () => {
    setCurrentFoodIndex((prev) => (prev + 1) % recipes.length);
  };

  const resetSelection = () => {
    setSelectedMealTime(null);
    setSelectedCategory(null);
    setSelectedFood(null);
    setCurrentFoodIndex(0);
    setRecipes([]);
    setShowIngredientSearch(false);
    setSelectedIngredients([]);
    setSearchQuery('');
  };

  const toggleIngredient = (ingredient: string) => {
    setSelectedIngredients(prev => 
      prev.includes(ingredient) 
        ? prev.filter(i => i !== ingredient)
        : [...prev, ingredient]
    );
  };

  const addCustomIngredient = () => {
    if (customIngredient.trim() && !selectedIngredients.includes(customIngredient.trim())) {
      setSelectedIngredients(prev => [...prev, customIngredient.trim()]);
      setCustomIngredient('');
    }
  };

  const removeIngredient = (ingredient: string) => {
    setSelectedIngredients(prev => prev.filter(i => i !== ingredient));
  };

  if (selectedFood) {
    const cookingTip = generateCookingTip(selectedFood);

    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedFood(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to suggestions
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden">
          <img
            src={selectedFood.image}
            alt={selectedFood.title}
            className="w-full h-64 object-cover"
          />
          
          <div className="p-8">
            <h1 className="text-3xl font-bold text-white mb-4">{selectedFood.title}</h1>
            
            <div className="grid grid-cols-4 gap-4 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-400">{selectedFood.calories || 'N/A'}</div>
                <div className="text-white/70 text-sm">Calories</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">{selectedFood.readyInMinutes}min</div>
                <div className="text-white/70 text-sm">Prep Time</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">{selectedFood.servings}</div>
                <div className="text-white/70 text-sm">Servings</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-400">
                  {selectedFood.nutrition ? Math.round(selectedFood.nutrition.protein) + 'g' : 'N/A'}
                </div>
                <div className="text-white/70 text-sm">Protein</div>
              </div>
            </div>

            {selectedFood.summary && (
              <p className="text-white/80 text-lg mb-6">{selectedFood.summary.replace(/<[^>]*>/g, '')}</p>
            )}

            <div className="mb-6">
              <h3 className="text-white font-semibold mb-3">Ingredients ({selectedFood.ingredients.length})</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {selectedFood.ingredients.slice(0, 12).map((ingredient: string, index: number) => (
                  <div key={index} className="bg-white/5 rounded-lg px-3 py-2 text-white/80 text-sm">
                    {ingredient}
                  </div>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-white font-semibold mb-3">Instructions</h3>
              <div className="bg-white/5 rounded-xl p-4">
                <p className="text-white/80 text-sm leading-relaxed">
                  {selectedFood.instructions.replace(/<[^>]*>/g, '').substring(0, 300)}...
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl p-4 mb-6 border border-green-500/30">
              <h3 className="text-green-300 font-semibold mb-2">🍳 Chef's Tip</h3>
              <p className="text-green-300 text-sm">{cookingTip}</p>
            </div>

            <div className="flex space-x-4">
              <button className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center">
                <ChefHat className="h-5 w-5 mr-2" />
                Start Cooking
              </button>
              <button 
                onClick={() => setSelectedFood(null)}
                className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all"
              >
                More Options
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (showIngredientSearch) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setShowIngredientSearch(false)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to options
        </button>

        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white mb-4">What ingredients do you have?</h2>
          <p className="text-white/70">Select ingredients and we'll suggest recipes you can make</p>
        </div>

        {selectedIngredients.length > 0 && (
          <div className="mb-8">
            <h3 className="text-white font-semibold mb-3">Selected Ingredients ({selectedIngredients.length})</h3>
            <div className="flex flex-wrap gap-2">
              {selectedIngredients.map((ingredient, index) => (
                <span 
                  key={index}
                  className="bg-green-500/20 text-green-300 px-3 py-1 rounded-full text-sm flex items-center"
                >
                  {ingredient}
                  <button 
                    onClick={() => removeIngredient(ingredient)}
                    className="ml-2 text-green-300 hover:text-white"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>
        )}

        <div className="mb-8">
          <div className="flex space-x-4 mb-4">
            <input
              type="text"
              value={customIngredient}
              onChange={(e) => setCustomIngredient(e.target.value)}
              placeholder="Add custom ingredient..."
              className="flex-1 bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white placeholder-white/50"
              onKeyPress={(e) => e.key === 'Enter' && addCustomIngredient()}
            />
            <button
              onClick={addCustomIngredient}
              className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-xl transition-colors"
            >
              Add
            </button>
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-white font-semibold mb-4">Common Ingredients</h3>
          <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-6 gap-3">
            {commonIngredients.map((ingredient) => (
              <button
                key={ingredient}
                onClick={() => toggleIngredient(ingredient)}
                className={`p-3 rounded-xl text-sm font-medium transition-all ${
                  selectedIngredients.includes(ingredient)
                    ? 'bg-green-500 text-white'
                    : 'bg-white/10 text-white/80 hover:bg-white/20'
                }`}
              >
                {ingredient}
              </button>
            ))}
          </div>
        </div>

        {loading && (
          <div className="text-center py-12">
            <Loader className="h-12 w-12 text-green-400 animate-spin mx-auto mb-4" />
            <p className="text-white/70">Finding recipes with your ingredients...</p>
          </div>
        )}

        {recipes.length > 0 && !loading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recipes.map((recipe, index) => (
              <div
                key={recipe.id}
                className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden cursor-pointer hover:bg-white/20 transition-all transform hover:scale-105"
                onClick={() => setSelectedFood(recipe)}
              >
                <img
                  src={recipe.image}
                  alt={recipe.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold text-white mb-2">{recipe.title}</h3>
                  <div className="flex items-center space-x-4 mb-3 text-sm text-white/70">
                    <span>{recipe.readyInMinutes}min</span>
                    <span>{recipe.calories || 'N/A'} cal</span>
                    <span>{recipe.servings} servings</span>
                  </div>
                  <button className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white py-2 px-4 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all">
                    View Recipe
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (selectedMealTime && selectedCategory) {
    if (loading) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Change selection
          </button>

          <div className="text-center py-20">
            <Loader className="h-12 w-12 text-green-400 animate-spin mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Finding Perfect Recipes</h2>
            <p className="text-white/70">Searching for {selectedCategory} {selectedMealTime} ideas...</p>
          </div>
        </div>
      );
    }

    const currentFood = recipes[currentFoodIndex];
    if (!currentFood) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <p className="text-white mb-4">No recipes found for this combination. Try another!</p>
          <button onClick={resetSelection} className="text-blue-300 hover:text-blue-200">
            Start over
          </button>
        </div>
      );
    }

    const cookingTip = generateCookingTip(currentFood);

    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={resetSelection}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Change selection
        </button>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            {selectedCategory} {selectedMealTime} Ideas
          </h2>
          <p className="text-white/70">Real recipes with nutritional information</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden max-w-2xl mx-auto">
          <img
            src={currentFood.image}
            alt={currentFood.title}
            className="w-full h-64 object-cover"
          />
          
          <div className="p-6">
            <h3 className="text-2xl font-bold text-white mb-2">{currentFood.title}</h3>
            
            <div className="flex items-center space-x-4 mb-4">
              <span className="bg-orange-500/20 text-orange-300 px-3 py-1 rounded-full text-sm">
                {currentFood.calories || 'N/A'} cal
              </span>
              <span className="bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full text-sm">
                {currentFood.readyInMinutes}min
              </span>
              <span className="bg-green-500/20 text-green-300 px-3 py-1 rounded-full text-sm">
                {currentFood.servings} servings
              </span>
            </div>

            {currentFood.summary && (
              <p className="text-white/80 mb-4">{currentFood.summary.replace(/<[^>]*>/g, '').substring(0, 120)}...</p>
            )}

            <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl p-4 mb-6 border border-green-500/30">
              <p className="text-green-300 text-sm">{cookingTip}</p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setSelectedFood(currentFood)}
                className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center"
              >
                <ThumbsUp className="h-5 w-5 mr-2" />
                Cook This
              </button>
              <button
                onClick={handleNext}
                className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all flex items-center justify-center"
              >
                <ThumbsDown className="h-5 w-5 mr-2" />
                Pass
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-white/60 mt-6">
          {currentFoodIndex + 1} of {recipes.length} suggestions
        </p>
      </div>
    );
  }

  if (selectedMealTime) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedMealTime(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Change meal time
        </button>

        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            What kind of {selectedMealTime.toLowerCase()} are you craving?
          </h2>
          <p className="text-xl text-white/80">Choose a category to get personalized recipe suggestions</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <button
              key={category.name}
              onClick={() => setSelectedCategory(category.name)}
              className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
            >
              <div className={`w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-r ${category.color} flex items-center justify-center transform group-hover:scale-110 transition-transform`}>
                <category.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white group-hover:text-blue-300 transition-colors">
                {category.name}
              </h3>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          What to <span className="bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">Cook</span>?
        </h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
          Discover recipes with real nutritional data, cooking times, and step-by-step instructions
        </p>
      </div>

      {/* Search Options */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <button
          onClick={() => setShowIngredientSearch(true)}
          className="bg-gradient-to-r from-green-500 to-emerald-500 text-white p-6 rounded-2xl hover:from-green-600 hover:to-emerald-600 transition-all transform hover:scale-105"
        >
          <Search className="h-8 w-8 mx-auto mb-3" />
          <h3 className="text-lg font-bold mb-2">Search by Ingredients</h3>
          <p className="text-sm opacity-90">Tell us what you have, we'll suggest recipes</p>
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6">
          <div className="flex items-center space-x-3 mb-4">
            <Search className="h-6 w-6 text-blue-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search recipes..."
              className="flex-1 bg-transparent text-white placeholder-white/50 outline-none"
              onKeyPress={(e) => e.key === 'Enter' && searchRecipes()}
            />
          </div>
          <button
            onClick={searchRecipes}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-xl transition-colors"
          >
            Search Recipes
          </button>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 text-center">
          <ChefHat className="h-8 w-8 text-purple-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-2">Browse by Meal</h3>
          <p className="text-sm text-white/70">Choose meal time and category</p>
        </div>
      </div>

      {/* Meal Times */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {mealTimes.map((mealTime) => (
          <button
            key={mealTime.name}
            onClick={() => setSelectedMealTime(mealTime.name)}
            className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
          >
            <div className={`w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-r ${mealTime.color} flex items-center justify-center text-4xl transform group-hover:scale-110 transition-transform`}>
              {mealTime.icon}
            </div>
            <h3 className="text-xl font-bold text-white group-hover:text-blue-300 transition-colors">
              {mealTime.name}
            </h3>
          </button>
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-green-500/10 to-emerald-500/10 backdrop-blur-md rounded-2xl border border-green-500/20 p-8">
        <h3 className="text-green-300 font-semibold mb-4">🍳 Real Recipe Database</h3>
        <p className="text-white/80 mb-4">
          Our system uses Spoonacular and TheMealDB APIs to provide real recipes with accurate nutritional information, 
          cooking times, and detailed instructions from professional chefs worldwide.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-white/70">
          <div>✨ Real nutritional data (calories, protein, carbs)</div>
          <div>⏱️ Accurate cooking and prep times</div>
          <div>🥘 Thousands of recipes from around the world</div>
          <div>📝 Step-by-step cooking instructions</div>
        </div>
      </div>
    </div>
  );
};

export default FoodPage;