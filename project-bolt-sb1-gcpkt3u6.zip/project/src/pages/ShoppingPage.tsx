import React, { useState, useEffect } from 'react';
import { MapPin, Check, X, Plus, ShoppingBag, Loader, Navigation, Phone, Globe } from 'lucide-react';
import { getCurrentLocation, getSupermarkets, formatDistance, Place, UserLocation } from '../services/locationService';

const categories = [
  {
    name: 'Essentials',
    description: 'Basic necessities you always need',
    color: 'from-blue-500 to-cyan-500',
    icon: '🛒'
  },
  {
    name: 'Weekly Groceries',
    description: 'Complete grocery list for the week',
    color: 'from-green-500 to-emerald-500',
    icon: '🥬'
  },
  {
    name: 'Household Items',
    description: 'Cleaning supplies and home goods',
    color: 'from-purple-500 to-indigo-500',
    icon: '🏠'
  },
  {
    name: 'Personal Care',
    description: 'Health and beauty essentials',
    color: 'from-pink-500 to-rose-500',
    icon: '💄'
  }
];

const mockLists = {
  'Essentials': {
    items: [
      { name: 'Milk', category: 'Dairy', price: '$3.99', essential: true },
      { name: 'Bread', category: 'Bakery', price: '$2.49', essential: true },
      { name: 'Eggs', category: 'Dairy', price: '$4.29', essential: true },
      { name: 'Rice', category: 'Grains', price: '$5.99', essential: true },
      { name: 'Chicken Breast', category: 'Meat', price: '$8.99', essential: true },
      { name: 'Bananas', category: 'Produce', price: '$1.99', essential: true },
      { name: 'Onions', category: 'Produce', price: '$2.99', essential: true },
      { name: 'Pasta', category: 'Pantry', price: '$1.99', essential: true }
    ],
    aiInsight: "These are the fundamental items that form the backbone of most meals. Having these essentials ensures you can always prepare a basic, nutritious meal."
  },
  'Weekly Groceries': {
    items: [
      { name: 'Fresh Spinach', category: 'Produce', price: '$3.49', essential: false },
      { name: 'Greek Yogurt', category: 'Dairy', price: '$5.99', essential: false },
      { name: 'Olive Oil', category: 'Pantry', price: '$7.99', essential: true },
      { name: 'Garlic', category: 'Produce', price: '$1.99', essential: true },
      { name: 'Tomatoes', category: 'Produce', price: '$3.99', essential: false },
      { name: 'Cheese', category: 'Dairy', price: '$6.99', essential: false },
      { name: 'Salmon Fillet', category: 'Seafood', price: '$12.99', essential: false },
      { name: 'Avocados', category: 'Produce', price: '$4.99', essential: false }
    ],
    aiInsight: "This expanded list covers a week's worth of varied, healthy meals. Mix and match these ingredients for endless meal possibilities!"
  },
  'Household Items': {
    items: [
      { name: 'All-Purpose Cleaner', category: 'Cleaning', price: '$4.99', essential: true },
      { name: 'Laundry Detergent', category: 'Cleaning', price: '$8.99', essential: true },
      { name: 'Dish Soap', category: 'Cleaning', price: '$3.49', essential: true },
      { name: 'Paper Towels', category: 'Paper Goods', price: '$6.99', essential: false },
      { name: 'Toilet Paper', category: 'Paper Goods', price: '$12.99', essential: true },
      { name: 'Trash Bags', category: 'Storage', price: '$7.99', essential: true },
      { name: 'Sponges', category: 'Cleaning', price: '$2.99', essential: false },
      { name: 'Glass Cleaner', category: 'Cleaning', price: '$3.99', essential: false }
    ],
    aiInsight: "Keep your home clean and organized with these essential household supplies. Focus on multi-purpose cleaners to maximize value and minimize clutter."
  },
  'Personal Care': {
    items: [
      { name: 'Shampoo', category: 'Hair Care', price: '$6.99', essential: true },
      { name: 'Body Wash', category: 'Bath', price: '$4.99', essential: true },
      { name: 'Toothpaste', category: 'Oral Care', price: '$3.49', essential: true },
      { name: 'Deodorant', category: 'Personal', price: '$4.99', essential: true },
      { name: 'Face Moisturizer', category: 'Skincare', price: '$8.99', essential: false },
      { name: 'Sunscreen', category: 'Skincare', price: '$7.99', essential: false },
      { name: 'Vitamins', category: 'Health', price: '$12.99', essential: false },
      { name: 'Hand Lotion', category: 'Skincare', price: '$5.99', essential: false }
    ],
    aiInsight: "Maintain your health and wellness with these personal care essentials. Prioritize items you use daily and consider seasonal needs like sunscreen."
  }
};

const ShoppingPage = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [nearbyStores, setNearbyStores] = useState<Place[]>([]);
  const [selectedStore, setSelectedStore] = useState<Place | null>(null);
  const [locationLoading, setLocationLoading] = useState(true);
  const [storesLoading, setStoresLoading] = useState(false);
  const [showStores, setShowStores] = useState(false);

  useEffect(() => {
    initializeLocation();
  }, []);

  const initializeLocation = async () => {
    try {
      setLocationLoading(true);
      const location = await getCurrentLocation();
      setUserLocation(location);
      loadNearbyStores(location);
    } catch (error) {
      console.error('Failed to get location:', error);
      // Set default location
      const defaultLocation = {
        lat: 40.7128,
        lon: -74.0060,
        city: 'New York',
        country: 'United States'
      };
      setUserLocation(defaultLocation);
      loadNearbyStores(defaultLocation);
    } finally {
      setLocationLoading(false);
    }
  };

  const loadNearbyStores = async (location: UserLocation) => {
    try {
      setStoresLoading(true);
      const stores = await getSupermarkets(location.lat, location.lon);
      setNearbyStores(stores);
    } catch (error) {
      console.error('Failed to load nearby stores:', error);
    } finally {
      setStoresLoading(false);
    }
  };

  const toggleItem = (itemName: string) => {
    const newChecked = new Set(checkedItems);
    if (newChecked.has(itemName)) {
      newChecked.delete(itemName);
    } else {
      newChecked.add(itemName);
    }
    setCheckedItems(newChecked);
  };

  const resetSelection = () => {
    setSelectedCategory(null);
    setCheckedItems(new Set());
    setShowStores(false);
    setSelectedStore(null);
  };

  const getDirections = (store: Place) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${store.lat},${store.lon}`;
    window.open(url, '_blank');
  };

  const callStore = (phone: string) => {
    window.open(`tel:${phone}`, '_self');
  };

  const visitWebsite = (website: string) => {
    window.open(website.startsWith('http') ? website : `https://${website}`, '_blank');
  };

  if (locationLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center py-20">
          <Loader className="h-12 w-12 text-blue-400 animate-spin mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Getting Your Location</h2>
          <p className="text-white/70">Finding the best stores near you...</p>
        </div>
      </div>
    );
  }

  if (selectedStore) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedStore(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to stores
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">{selectedStore.name}</h1>
              <div className="flex items-center text-white/70">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{selectedStore.distance ? formatDistance(selectedStore.distance / 1000) : 'Nearby'}</span>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <p className="text-white/80 mb-2">{selectedStore.formatted}</p>
            {selectedStore.details?.contact?.phone && (
              <p className="text-blue-300">{selectedStore.details.contact.phone}</p>
            )}
          </div>

          <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-xl p-4 mb-6 border border-blue-500/30">
            <h3 className="text-blue-300 font-semibold mb-2">Store Information</h3>
            <p className="text-blue-300 text-sm">
              This store is conveniently located in {selectedStore.city || 'your area'} and offers a wide selection of groceries and household items.
              {selectedStore.distance && ` It's just ${formatDistance(selectedStore.distance / 1000)} away from your location.`}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button 
              onClick={() => getDirections(selectedStore)}
              className="bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center"
            >
              <Navigation className="h-5 w-5 mr-2" />
              Get Directions
            </button>
            
            {selectedStore.details?.contact?.phone && (
              <button 
                onClick={() => callStore(selectedStore.details!.contact!.phone!)}
                className="bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all flex items-center justify-center"
              >
                <Phone className="h-5 w-5 mr-2" />
                Call Store
              </button>
            )}
            
            {selectedStore.details?.contact?.website && (
              <button 
                onClick={() => visitWebsite(selectedStore.details!.contact!.website!)}
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all flex items-center justify-center"
              >
                <Globe className="h-5 w-5 mr-2" />
                Website
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (showStores && nearbyStores.length > 0) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setShowStores(false)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to shopping lists
        </button>

        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Nearby Stores & Supermarkets
          </h2>
          <div className="flex items-center justify-center text-white/60">
            <MapPin className="h-5 w-5 mr-2" />
            <span>Near {userLocation?.city || 'your location'}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {nearbyStores.map((store, index) => (
            <div
              key={store.place_id || index}
              className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden cursor-pointer hover:bg-white/20 transition-all transform hover:scale-105"
              onClick={() => setSelectedStore(store)}
            >
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{store.name}</h3>
                
                <div className="flex items-center mb-3 text-white/70">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{store.distance ? formatDistance(store.distance / 1000) : 'Nearby'}</span>
                </div>

                <p className="text-white/60 text-sm mb-4">{store.formatted}</p>

                <button className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white py-2 px-4 rounded-xl font-semibold hover:from-blue-600 hover:to-cyan-600 transition-all">
                  View Store Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (selectedCategory) {
    const list = mockLists[selectedCategory as keyof typeof mockLists];
    const totalPrice = list.items.reduce((sum, item) => {
      return sum + parseFloat(item.price.replace('$', ''));
    }, 0);

    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={resetSelection}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to categories
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">{selectedCategory}</h1>
              <div className="flex items-center text-white/70">
                <MapPin className="h-4 w-4 mr-1" />
                <span>Based on {userLocation?.city || 'your location'}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-green-400">${totalPrice.toFixed(2)}</div>
              <div className="text-white/60 text-sm">Estimated total</div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-xl p-4 mb-6 border border-blue-500/30">
            <p className="text-blue-300 text-sm">{list.aiInsight}</p>
          </div>

          <div className="space-y-3">
            {list.items.map((item, index) => {
              const isChecked = checkedItems.has(item.name);
              return (
                <div
                  key={index}
                  className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                    isChecked
                      ? 'bg-green-500/20 border-green-500/50'
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <button
                      onClick={() => toggleItem(item.name)}
                      className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                        isChecked
                          ? 'bg-green-500 border-green-500'
                          : 'border-white/30 hover:border-white/50'
                      }`}
                    >
                      {isChecked && <Check className="h-4 w-4 text-white" />}
                    </button>
                    <div>
                      <h3 className={`font-semibold ${isChecked ? 'text-white line-through' : 'text-white'}`}>
                        {item.name}
                      </h3>
                      <p className="text-white/60 text-sm">{item.category}</p>
                    </div>
                    {item.essential && (
                      <span className="bg-orange-500/20 text-orange-300 px-2 py-1 rounded-full text-xs">
                        Essential
                      </span>
                    )}
                  </div>
                  <div className="text-white font-semibold">{item.price}</div>
                </div>
              );
            })}
          </div>

          <div className="mt-8 flex space-x-4">
            <button 
              onClick={() => setShowStores(true)}
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center"
            >
              <ShoppingBag className="h-5 w-5 mr-2" />
              Find Nearby Stores
            </button>
            <button className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all flex items-center justify-center">
              <Plus className="h-5 w-5 mr-2" />
              Add Custom Item
            </button>
          </div>

          <div className="mt-6 text-center">
            <p className="text-white/60 text-sm">
              Checked items: {checkedItems.size} / {list.items.length}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          Smart <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Shopping</span>
        </h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto mb-6">
          AI-powered shopping lists with real nearby store locations
        </p>
        <div className="flex items-center justify-center text-white/60">
          <MapPin className="h-5 w-5 mr-2" />
          <span>Shopping suggestions for {userLocation?.city || 'your area'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {categories.map((category) => (
          <button
            key={category.name}
            onClick={() => setSelectedCategory(category.name)}
            className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 text-left"
          >
            <div className={`w-16 h-16 mb-4 rounded-xl bg-gradient-to-r ${category.color} flex items-center justify-center text-3xl transform group-hover:scale-110 transition-transform`}>
              {category.icon}
            </div>
            
            <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-blue-300 transition-colors">
              {category.name}
            </h3>
            
            <p className="text-white/70 leading-relaxed">
              {category.description}
            </p>
            
            <div className="mt-4 flex items-center text-blue-300 group-hover:text-blue-200 transition-colors">
              <span className="text-sm font-semibold">View List</span>
              <svg className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" 
                   fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </button>
        ))}
      </div>

      {nearbyStores.length > 0 && (
        <div className="mt-8">
          <button
            onClick={() => setShowStores(true)}
            className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 text-white py-4 px-8 rounded-2xl font-semibold hover:from-purple-600 hover:to-indigo-600 transition-all flex items-center justify-center"
          >
            <MapPin className="h-5 w-5 mr-2" />
            View {nearbyStores.length} Nearby Stores
          </button>
        </div>
      )}

      <div className="mt-12 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
        <h3 className="text-white font-semibold mb-3">Real Location Integration</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-white/70">
          <div>
            <span className="text-blue-300 font-semibold">📍 Live Store Data</span>
            <p>Real supermarkets and stores based on your location</p>
          </div>
          <div>
            <span className="text-green-300 font-semibold">🛒 Smart Lists</span>
            <p>AI curates essential items based on nutrition and value</p>
          </div>
          <div>
            <span className="text-purple-300 font-semibold">🗺️ Easy Navigation</span>
            <p>Direct links to maps, directions, and store contact info</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShoppingPage;