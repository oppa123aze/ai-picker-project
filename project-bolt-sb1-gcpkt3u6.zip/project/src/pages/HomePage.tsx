import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Film, 
  Utensils, 
  ShoppingCart, 
  MapPin, 
  Gamepad2, 
  Music,
  Book,
  Car,
  Heart,
  Briefcase,
  Plane,
  Gift
} from 'lucide-react';

const categories = [
  {
    id: 'movies',
    title: 'What to Watch',
    description: 'Movies, shows, and entertainment based on your mood',
    icon: Film,
    gradient: 'from-red-500 to-pink-500',
    path: '/movies'
  },
  {
    id: 'food',
    title: 'What to Cook',
    description: 'Recipe suggestions with real nutritional data',
    icon: Utensils,
    gradient: 'from-green-500 to-emerald-500',
    path: '/food'
  },
  {
    id: 'music',
    title: 'What to Listen',
    description: 'Music and podcasts that match your mood',
    icon: Music,
    gradient: 'from-pink-500 to-rose-500',
    path: '/music'
  },
  {
    id: 'books',
    title: 'What to Read',
    description: 'Book recommendations from millions of titles',
    icon: Book,
    gradient: 'from-blue-500 to-indigo-500',
    path: '/books'
  },
  {
    id: 'restaurants',
    title: 'Where to Eat',
    description: 'Restaurants from 24 cuisines worldwide near you',
    icon: MapPin,
    gradient: 'from-orange-500 to-red-500',
    path: '/restaurants'
  },
  {
    id: 'activities',
    title: 'What to Do',
    description: 'Real activities and places near your location',
    icon: Gamepad2,
    gradient: 'from-purple-500 to-indigo-500',
    path: '/activities'
  },
  {
    id: 'shopping',
    title: 'Where to Shop',
    description: 'Smart shopping lists and nearby stores',
    icon: ShoppingCart,
    gradient: 'from-blue-500 to-cyan-500',
    path: '/shopping'
  },
  {
    id: 'travel',
    title: 'Where to Go',
    description: 'Travel destinations and trip planning',
    icon: Plane,
    gradient: 'from-teal-500 to-green-500',
    path: '/travel'
  },
  {
    id: 'gifts',
    title: 'What to Gift',
    description: 'Perfect gift ideas for any occasion',
    icon: Gift,
    gradient: 'from-violet-500 to-purple-500',
    path: '/gifts'
  }
];

const HomePage = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
          Stop <span className="text-red-400">Overthinking</span>
        </h1>
        <p className="text-xl md:text-2xl text-white/80 mb-8 max-w-3xl mx-auto">
          Let AI eliminate your decision paralysis. From what to watch to where to eat, 
          we've got smart suggestions for every aspect of your life.
        </p>
        <div className="flex items-center justify-center space-x-4 text-white/60">
          <span className="text-6xl">🤔</span>
          <span className="text-2xl">→</span>
          <span className="text-6xl">✨</span>
          <span className="text-2xl">→</span>
          <span className="text-6xl">😊</span>
        </div>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((category) => (
          <Link
            key={category.id}
            to={category.path}
            className="group relative overflow-hidden rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
          >
            <div className="absolute inset-0 bg-gradient-to-br opacity-0 group-hover:opacity-20 transition-opacity duration-300" 
                 style={{backgroundImage: `linear-gradient(to bottom right, ${category.gradient.split(' ')[1]}, ${category.gradient.split(' ')[3]})`}} />
            
            <div className="relative p-8">
              <div className={`inline-flex p-4 rounded-xl bg-gradient-to-r ${category.gradient} mb-4`}>
                <category.icon className="h-8 w-8 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-blue-300 transition-colors">
                {category.title}
              </h3>
              
              <p className="text-white/70 leading-relaxed">
                {category.description}
              </p>
              
              <div className="mt-6 flex items-center text-blue-300 group-hover:text-blue-200 transition-colors">
                <span className="text-sm font-semibold">Get Suggestions</span>
                <svg className="ml-2 h-4 w-4 transform group-hover:translate-x-1 transition-transform" 
                     fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Bottom CTA */}
      <div className="text-center mt-16">
        <p className="text-white/60 text-lg">
          Life's too short for endless scrolling and decision fatigue
        </p>
        <p className="text-white/80 text-xl font-semibold mt-2">
          Let AI make your choices smarter, faster, and better ✨
        </p>
      </div>
    </div>
  );
};

export default HomePage;