import React, { useState, useEffect } from 'react';
import { Gift, Heart, Star, Users, Baby, Briefcase, X, ThumbsUp, ThumbsDown, Loader, ExternalLink } from 'lucide-react';

const occasions = [
  { name: 'Birthday', emoji: '🎂', color: 'from-pink-500 to-rose-500' },
  { name: 'Anniversary', emoji: '💕', color: 'from-red-500 to-pink-500' },
  { name: 'Wedding', emoji: '💒', color: 'from-purple-500 to-pink-500' },
  { name: 'Graduation', emoji: '🎓', color: 'from-blue-500 to-indigo-500' },
  { name: 'Holiday', emoji: '🎄', color: 'from-green-500 to-red-500' },
  { name: 'New Job', emoji: '💼', color: 'from-orange-500 to-yellow-500' },
  { name: 'Housewarming', emoji: '🏠', color: 'from-teal-500 to-green-500' },
  { name: 'Just Because', emoji: '✨', color: 'from-violet-500 to-purple-500' }
];

const recipients = [
  { name: 'Partner', icon: Heart, color: 'from-red-500 to-pink-500' },
  { name: 'Friend', icon: Users, color: 'from-blue-500 to-indigo-500' },
  { name: 'Family', icon: Users, color: 'from-green-500 to-emerald-500' },
  { name: 'Colleague', icon: Briefcase, color: 'from-purple-500 to-indigo-500' },
  { name: 'Child', icon: Baby, color: 'from-yellow-500 to-orange-500' },
  { name: 'Parent', icon: Heart, color: 'from-orange-500 to-red-500' }
];

interface GiftIdea {
  title: string;
  description: string;
  price: string;
  category: string;
  reason: string;
  where: string;
}

const GiftsPage = () => {
  const [selectedOccasion, setSelectedOccasion] = useState<string | null>(null);
  const [selectedRecipient, setSelectedRecipient] = useState<string | null>(null);
  const [selectedGift, setSelectedGift] = useState<GiftIdea | null>(null);
  const [giftIdeas, setGiftIdeas] = useState<GiftIdea[]>([]);
  const [currentGiftIndex, setCurrentGiftIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const [budget, setBudget] = useState<string>('');
  const [interests, setInterests] = useState<string>('');

  const generateGiftIdeas = async (occasion: string, recipient: string) => {
    setLoading(true);
    try {
      // Simulate AI-generated gift ideas
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const ideas = generateSmartGiftSuggestions(occasion, recipient, budget, interests);
      setGiftIdeas(ideas);
      setCurrentGiftIndex(0);
    } catch (error) {
      console.error('Error generating gift ideas:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateSmartGiftSuggestions = (occasion: string, recipient: string, budget: string, interests: string): GiftIdea[] => {
    const giftDatabase = {
      'Birthday-Partner': [
        {
          title: 'Personalized Star Map',
          description: 'Custom star map showing the night sky from a special date',
          price: '$25-45',
          category: 'Personalized',
          reason: 'Romantic and meaningful, captures a special moment in time',
          where: 'Etsy, Amazon, or custom print shops'
        },
        {
          title: 'Subscription Box',
          description: 'Monthly subscription based on their interests (coffee, books, skincare)',
          price: '$15-50/month',
          category: 'Experience',
          reason: 'Gift that keeps giving, shows you pay attention to their interests',
          where: 'Various subscription services online'
        },
        {
          title: 'Smart Photo Frame',
          description: 'Digital frame that displays rotating photos from your phone',
          price: '$80-150',
          category: 'Tech',
          reason: 'Modern way to share memories, perfect for long-distance relationships',
          where: 'Best Buy, Amazon, Target'
        }
      ],
      'Anniversary-Partner': [
        {
          title: 'Memory Scrapbook',
          description: 'Handmade scrapbook with photos and memories from your relationship',
          price: '$20-40',
          category: 'Handmade',
          reason: 'Deeply personal and shows effort, perfect for reminiscing together',
          where: 'Craft stores for supplies, make it yourself'
        },
        {
          title: 'Couples Experience',
          description: 'Wine tasting, cooking class, or spa day for two',
          price: '$100-300',
          category: 'Experience',
          reason: 'Creates new memories together, strengthens your bond',
          where: 'Local venues, Groupon, experience gift websites'
        }
      ],
      'Birthday-Friend': [
        {
          title: 'Funny Coffee Mug',
          description: 'Mug with inside joke or funny quote that reminds them of you',
          price: '$10-20',
          category: 'Humor',
          reason: 'Personal touch with humor, useful daily reminder of friendship',
          where: 'Custom print shops, Etsy, local stores'
        },
        {
          title: 'Plant & Cute Pot',
          description: 'Low-maintenance succulent in a decorative pot',
          price: '$15-30',
          category: 'Living',
          reason: 'Brings life to their space, easy to care for, trendy',
          where: 'Local nurseries, Home Depot, online plant stores'
        }
      ],
      'Holiday-Family': [
        {
          title: 'Family Game Night Set',
          description: 'Collection of board games perfect for family gatherings',
          price: '$30-80',
          category: 'Entertainment',
          reason: 'Encourages family bonding and creates lasting memories',
          where: 'Target, Amazon, local toy stores'
        },
        {
          title: 'Cozy Throw Blanket',
          description: 'Soft, warm blanket perfect for winter nights',
          price: '$25-60',
          category: 'Comfort',
          reason: 'Practical and cozy, perfect for the holiday season',
          where: 'Department stores, online retailers, home goods stores'
        }
      ]
    };

    const key = `${occasion}-${recipient}`;
    const baseIdeas = giftDatabase[key as keyof typeof giftDatabase] || giftDatabase['Birthday-Friend'];
    
    // Add some variety with additional generated ideas
    const additionalIdeas = [
      {
        title: 'Artisan Candle Set',
        description: 'Hand-poured candles with unique scents',
        price: '$20-45',
        category: 'Home',
        reason: 'Creates ambiance and shows thoughtfulness',
        where: 'Local artisan shops, Etsy, department stores'
      },
      {
        title: 'Book by Favorite Author',
        description: 'Latest release or special edition from an author they love',
        price: '$15-35',
        category: 'Literature',
        reason: 'Shows you know their interests and encourages relaxation',
        where: 'Bookstores, Amazon, local libraries'
      },
      {
        title: 'Gourmet Food Basket',
        description: 'Curated selection of artisan snacks and treats',
        price: '$30-80',
        category: 'Food',
        reason: 'Delicious and shareable, perfect for any occasion',
        where: 'Specialty food stores, online gourmet retailers'
      }
    ];

    return [...baseIdeas, ...additionalIdeas].slice(0, 6);
  };

  useEffect(() => {
    if (selectedOccasion && selectedRecipient) {
      generateGiftIdeas(selectedOccasion, selectedRecipient);
    }
  }, [selectedOccasion, selectedRecipient]);

  const handleNext = () => {
    setCurrentGiftIndex((prev) => (prev + 1) % giftIdeas.length);
  };

  const resetSelection = () => {
    setSelectedOccasion(null);
    setSelectedRecipient(null);
    setSelectedGift(null);
    setGiftIdeas([]);
    setCurrentGiftIndex(0);
    setBudget('');
    setInterests('');
  };

  if (selectedGift) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedGift(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to gift ideas
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">{selectedGift.title}</h1>
              <div className="flex items-center space-x-4 text-white/70">
                <span className="bg-green-500/20 text-green-300 px-3 py-1 rounded-full text-sm">
                  {selectedGift.price}
                </span>
                <span className="bg-purple-500/20 text-purple-300 px-3 py-1 rounded-full text-sm">
                  {selectedGift.category}
                </span>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-white font-semibold mb-2">Description</h3>
            <p className="text-white/80 mb-4">{selectedGift.description}</p>
          </div>

          <div className="mb-6">
            <h3 className="text-white font-semibold mb-2">Why This Gift?</h3>
            <p className="text-blue-300">{selectedGift.reason}</p>
          </div>

          <div className="mb-6">
            <h3 className="text-white font-semibold mb-2">Where to Buy</h3>
            <p className="text-green-300">{selectedGift.where}</p>
          </div>

          <div className="bg-gradient-to-r from-violet-500/20 to-purple-500/20 rounded-xl p-4 mb-6 border border-violet-500/30">
            <h3 className="text-violet-300 font-semibold mb-2">🎁 Gift Tip</h3>
            <p className="text-violet-300 text-sm">
              For {selectedOccasion?.toLowerCase()} gifts, presentation matters! Consider adding a handwritten note 
              explaining why you chose this specific gift for them.
            </p>
          </div>

          <div className="flex space-x-4">
            <button className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center">
              <ExternalLink className="h-5 w-5 mr-2" />
              Find Online
            </button>
            <button 
              onClick={() => setSelectedGift(null)}
              className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all"
            >
              More Ideas
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (selectedOccasion && selectedRecipient) {
    if (loading) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Start over
          </button>

          <div className="text-center py-20">
            <Loader className="h-12 w-12 text-violet-400 animate-spin mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Generating Perfect Gift Ideas</h2>
            <p className="text-white/70">AI is curating personalized suggestions for your {selectedOccasion.toLowerCase()} gift...</p>
          </div>
        </div>
      );
    }

    const currentGift = giftIdeas[currentGiftIndex];
    if (!currentGift) {
      return (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <p className="text-white mb-4">No gift ideas generated. Try again!</p>
          <button onClick={resetSelection} className="text-blue-300 hover:text-blue-200">
            Start over
          </button>
        </div>
      );
    }

    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={resetSelection}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Start over
        </button>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            Perfect {selectedOccasion} Gift for {selectedRecipient}
          </h2>
          <p className="text-white/70">AI-curated suggestions just for you</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden max-w-2xl mx-auto">
          <div className="p-6">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-white mb-2">{currentGift.title}</h3>
              <div className="flex justify-center items-center space-x-3 mb-3">
                <span className="bg-green-500/20 text-green-300 px-3 py-1 rounded-full text-sm">
                  {currentGift.price}
                </span>
                <span className="bg-purple-500/20 text-purple-300 px-3 py-1 rounded-full text-sm">
                  {currentGift.category}
                </span>
              </div>
            </div>

            <p className="text-white/80 mb-4 text-center">{currentGift.description}</p>

            <div className="bg-gradient-to-r from-violet-500/20 to-purple-500/20 rounded-xl p-4 mb-6 border border-violet-500/30">
              <p className="text-violet-300 text-sm text-center">{currentGift.reason}</p>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setSelectedGift(currentGift)}
                className="flex-1 bg-gradient-to-r from-violet-500 to-purple-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-violet-600 hover:to-purple-600 transition-all flex items-center justify-center"
              >
                <ThumbsUp className="h-5 w-5 mr-2" />
                Perfect!
              </button>
              <button
                onClick={handleNext}
                className="flex-1 bg-white/10 text-white py-3 px-6 rounded-xl font-semibold border border-white/20 hover:bg-white/20 transition-all flex items-center justify-center"
              >
                <ThumbsDown className="h-5 w-5 mr-2" />
                Next Idea
              </button>
            </div>
          </div>
        </div>

        <p className="text-center text-white/60 mt-6">
          {currentGiftIndex + 1} of {giftIdeas.length} suggestions
        </p>
      </div>
    );
  }

  if (selectedOccasion) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedOccasion(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Change occasion
        </button>

        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-white mb-4">Who are you shopping for?</h2>
          <p className="text-white/70">Select the recipient to get personalized gift suggestions</p>
        </div>

        {/* Optional inputs for better suggestions */}
        <div className="max-w-2xl mx-auto mb-8 space-y-4">
          <div>
            <label className="block text-white font-semibold mb-2">Budget (optional)</label>
            <input
              type="text"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
              placeholder="e.g., $20-50, under $100"
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white placeholder-white/50"
            />
          </div>
          <div>
            <label className="block text-white font-semibold mb-2">Their interests (optional)</label>
            <input
              type="text"
              value={interests}
              onChange={(e) => setInterests(e.target.value)}
              placeholder="e.g., cooking, reading, fitness, art"
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-white placeholder-white/50"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {recipients.map((recipient) => (
            <button
              key={recipient.name}
              onClick={() => setSelectedRecipient(recipient.name)}
              className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
            >
              <div className={`w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-r ${recipient.color} flex items-center justify-center transform group-hover:scale-110 transition-transform`}>
                <recipient.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white group-hover:text-violet-300 transition-colors">
                {recipient.name}
              </h3>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          What to <span className="bg-gradient-to-r from-violet-400 to-purple-400 bg-clip-text text-transparent">Gift</span>?
        </h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto">
          AI-powered gift suggestions that show you really care
        </p>
      </div>

      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-4">What's the occasion?</h2>
        <p className="text-white/70">Choose the event to get perfectly tailored gift ideas</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {occasions.map((occasion) => (
          <button
            key={occasion.name}
            onClick={() => setSelectedOccasion(occasion.name)}
            className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
          >
            <div className={`w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-r ${occasion.color} flex items-center justify-center text-3xl transform group-hover:scale-110 transition-transform`}>
              {occasion.emoji}
            </div>
            <h3 className="text-lg font-bold text-white group-hover:text-violet-300 transition-colors">
              {occasion.name}
            </h3>
          </button>
        ))}
      </div>

      <div className="mt-12 bg-gradient-to-r from-violet-500/10 to-purple-500/10 backdrop-blur-md rounded-2xl border border-violet-500/20 p-8">
        <h3 className="text-violet-300 font-semibold mb-4">🎁 AI-Powered Gift Intelligence</h3>
        <p className="text-white/80 mb-4">
          Our smart gift suggestions consider the occasion, recipient relationship, and your preferences 
          to recommend thoughtful gifts that create lasting memories and show you truly care.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-white/70">
          <div>✨ Personalized recommendations based on relationship</div>
          <div>💝 Budget-conscious options for every price range</div>
          <div>🎯 Occasion-specific suggestions that hit the mark</div>
          <div>🛍️ Direct links to where you can buy each gift</div>
        </div>
      </div>
    </div>
  );
};

export default GiftsPage;