import React, { useState, useEffect } from 'react';
import { MapPin, Star, Clock, DollarSign, X, Navigation, Phone, Loader, Globe } from 'lucide-react';
import { getCurrentLocation, getRestaurantsByCuisine, formatDistance, Place, UserLocation } from '../services/locationService';

const cuisineTypes = [
  { name: 'Italian', emoji: '🍝', color: 'from-red-400 to-orange-400' },
  { name: 'Asian', emoji: '🍜', color: 'from-yellow-400 to-red-400' },
  { name: 'Mexican', emoji: '🌮', color: 'from-green-400 to-yellow-400' },
  { name: 'American', emoji: '🍔', color: 'from-blue-400 to-red-400' },
  { name: 'Mediterranean', emoji: '🥙', color: 'from-blue-400 to-green-400' },
  { name: 'Indian', emoji: '🍛', color: 'from-orange-400 to-red-400' },
  { name: 'Chinese', emoji: '🥢', color: 'from-red-400 to-yellow-400' },
  { name: 'Japanese', emoji: '🍣', color: 'from-pink-400 to-red-400' },
  { name: 'Thai', emoji: '🌶️', color: 'from-green-400 to-red-400' },
  { name: 'French', emoji: '🥐', color: 'from-purple-400 to-pink-400' },
  { name: 'Greek', emoji: '🫒', color: 'from-blue-400 to-white' },
  { name: 'Turkish', emoji: '🥙', color: 'from-red-400 to-orange-400' },
  { name: 'Lebanese', emoji: '🧆', color: 'from-green-400 to-yellow-400' },
  { name: 'Korean', emoji: '🍲', color: 'from-red-400 to-pink-400' },
  { name: 'Vietnamese', emoji: '🍲', color: 'from-green-400 to-blue-400' },
  { name: 'Brazilian', emoji: '🥩', color: 'from-yellow-400 to-green-400' },
  { name: 'Moroccan', emoji: '🍯', color: 'from-orange-400 to-red-400' },
  { name: 'Ethiopian', emoji: '🌶️', color: 'from-yellow-400 to-red-400' },
  { name: 'Peruvian', emoji: '🌽', color: 'from-yellow-400 to-orange-400' },
  { name: 'Spanish', emoji: '🥘', color: 'from-red-400 to-yellow-400' },
  { name: 'German', emoji: '🍺', color: 'from-yellow-400 to-brown-400' },
  { name: 'Russian', emoji: '🥟', color: 'from-blue-400 to-white' },
  { name: 'Caribbean', emoji: '🥥', color: 'from-green-400 to-blue-400' },
  { name: 'African', emoji: '🍠', color: 'from-orange-400 to-brown-400' }
];

const RestaurantsPage = () => {
  const [selectedCuisine, setSelectedCuisine] = useState<string | null>(null);
  const [selectedRestaurant, setSelectedRestaurant] = useState<Place | null>(null);
  const [restaurants, setRestaurants] = useState<Place[]>([]);
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [locationLoading, setLocationLoading] = useState(true);

  useEffect(() => {
    initializeLocation();
  }, []);

  const initializeLocation = async () => {
    try {
      setLocationLoading(true);
      const location = await getCurrentLocation();
      setUserLocation(location);
    } catch (error) {
      console.error('Failed to get location:', error);
      setError('Unable to get your location. Using default location.');
      // Set default location (New York City)
      setUserLocation({
        lat: 40.7128,
        lon: -74.0060,
        city: 'New York',
        country: 'United States'
      });
    } finally {
      setLocationLoading(false);
    }
  };

  const loadRestaurants = async (cuisine: string) => {
    if (!userLocation) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const results = await getRestaurantsByCuisine(cuisine, userLocation.lat, userLocation.lon);
      if (results.length > 0) {
        setRestaurants(results);
      } else {
        setError(`No ${cuisine} restaurants found nearby. Try expanding your search area.`);
      }
    } catch (error) {
      setError('Failed to load restaurants. Please try again.');
      console.error('Error loading restaurants:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedCuisine && userLocation) {
      loadRestaurants(selectedCuisine);
    }
  }, [selectedCuisine, userLocation]);

  const resetSelection = () => {
    setSelectedCuisine(null);
    setSelectedRestaurant(null);
    setRestaurants([]);
    setError(null);
  };

  const getDirections = (restaurant: Place) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${restaurant.lat},${restaurant.lon}`;
    window.open(url, '_blank');
  };

  const callRestaurant = (phone: string) => {
    window.open(`tel:${phone}`, '_self');
  };

  const visitWebsite = (website: string) => {
    window.open(website.startsWith('http') ? website : `https://${website}`, '_blank');
  };

  const getRatingDisplay = (rating?: number): string => {
    if (!rating) return 'N/A';
    return rating.toFixed(1);
  };

  const getPriceRange = (categories: string[]): string => {
    // Simple price estimation based on categories
    if (categories.some(cat => cat.includes('fast_food') || cat.includes('cafe'))) return '$';
    if (categories.some(cat => cat.includes('fine_dining'))) return '$$$';
    return '$$';
  };

  if (locationLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center py-20">
          <Loader className="h-12 w-12 text-blue-400 animate-spin mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Getting Your Location</h2>
          <p className="text-white/70">Finding the best restaurants near you...</p>
        </div>
      </div>
    );
  }

  if (selectedRestaurant) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={() => setSelectedRestaurant(null)}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Back to restaurants
        </button>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden">
          <div className="p-8">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-white mb-2">{selectedRestaurant.name}</h1>
                <div className="flex items-center space-x-4 text-white/70">
                  {selectedRestaurant.details?.rating && (
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      <span>{getRatingDisplay(selectedRestaurant.details.rating)}</span>
                    </div>
                  )}
                  <span>{getPriceRange(selectedRestaurant.categories)}</span>
                  <span className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {selectedRestaurant.distance ? formatDistance(selectedRestaurant.distance / 1000) : 'Nearby'}
                  </span>
                </div>
              </div>
            </div>

            <div className="mb-6">
              <p className="text-white/80 mb-2">{selectedRestaurant.formatted}</p>
              {selectedRestaurant.details?.contact?.phone && (
                <p className="text-blue-300">{selectedRestaurant.details.contact.phone}</p>
              )}
            </div>

            {selectedRestaurant.categories.length > 0 && (
              <div className="mb-6">
                <h3 className="text-white font-semibold mb-3">Categories</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedRestaurant.categories.slice(0, 5).map((category, index) => (
                    <span key={index} className="bg-orange-500/20 text-orange-300 px-3 py-1 rounded-full text-sm">
                      {category.split('.').pop()?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-xl p-4 mb-6 border border-blue-500/30">
              <h3 className="text-blue-300 font-semibold mb-2">Location Info</h3>
              <p className="text-blue-300 text-sm">
                This restaurant is located in {selectedRestaurant.city || 'your area'} and offers authentic cuisine. 
                {selectedRestaurant.details?.rating && ` With a rating of ${getRatingDisplay(selectedRestaurant.details.rating)}, it's highly recommended by locals.`}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button 
                onClick={() => getDirections(selectedRestaurant)}
                className="bg-gradient-to-r from-green-500 to-emerald-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center"
              >
                <Navigation className="h-5 w-5 mr-2" />
                Directions
              </button>
              
              {selectedRestaurant.details?.contact?.phone && (
                <button 
                  onClick={() => callRestaurant(selectedRestaurant.details!.contact!.phone!)}
                  className="bg-gradient-to-r from-blue-500 to-purple-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all flex items-center justify-center"
                >
                  <Phone className="h-5 w-5 mr-2" />
                  Call
                </button>
              )}
              
              {selectedRestaurant.details?.contact?.website && (
                <button 
                  onClick={() => visitWebsite(selectedRestaurant.details!.contact!.website!)}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all flex items-center justify-center"
                >
                  <Globe className="h-5 w-5 mr-2" />
                  Website
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (selectedCuisine) {
    if (loading) {
      return (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Change cuisine
          </button>

          <div className="text-center py-20">
            <Loader className="h-12 w-12 text-orange-400 animate-spin mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Finding {selectedCuisine} Restaurants</h2>
            <p className="text-white/70">Searching for the best options near you...</p>
          </div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={resetSelection}
            className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
          >
            <X className="h-5 w-5 mr-2" />
            Change cuisine
          </button>

          <div className="text-center">
            <div className="bg-red-500/20 border border-red-500/30 rounded-xl p-6 mb-6">
              <p className="text-red-300 mb-4">{error}</p>
              <button 
                onClick={() => loadRestaurants(selectedCuisine)}
                className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-lg transition-colors"
              >
                Try Again
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <button
          onClick={resetSelection}
          className="mb-6 flex items-center text-white/70 hover:text-white transition-colors"
        >
          <X className="h-5 w-5 mr-2" />
          Change cuisine
        </button>

        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Best {selectedCuisine} Restaurants Nearby
          </h2>
          <div className="flex items-center justify-center text-white/60">
            <MapPin className="h-5 w-5 mr-2" />
            <span>Near {userLocation?.city || 'your location'}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {restaurants.map((restaurant, index) => (
            <div
              key={restaurant.place_id || index}
              className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden cursor-pointer hover:bg-white/20 transition-all transform hover:scale-105"
              onClick={() => setSelectedRestaurant(restaurant)}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-xl font-bold text-white">{restaurant.name}</h3>
                </div>

                <div className="flex items-center space-x-4 mb-3 text-white/70">
                  {restaurant.details?.rating && (
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      <span>{getRatingDisplay(restaurant.details.rating)}</span>
                    </div>
                  )}
                  <span>{getPriceRange(restaurant.categories)}</span>
                  <span>{restaurant.distance ? formatDistance(restaurant.distance / 1000) : 'Nearby'}</span>
                </div>

                <p className="text-white/60 text-sm mb-4">{restaurant.formatted}</p>

                <div className="flex flex-wrap gap-1 mb-4">
                  {restaurant.categories.slice(0, 2).map((category, idx) => (
                    <span key={idx} className="bg-orange-500/20 text-orange-300 px-2 py-1 rounded-full text-xs">
                      {category.split('.').pop()?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </span>
                  ))}
                </div>

                <button className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white py-2 px-4 rounded-xl font-semibold hover:from-blue-600 hover:to-purple-600 transition-all">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          Where to <span className="bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent">Dine</span>?
        </h1>
        <p className="text-xl text-white/80 max-w-2xl mx-auto mb-6">
          Discover authentic restaurants from around the world near you
        </p>
        <div className="flex items-center justify-center text-white/60">
          <MapPin className="h-5 w-5 mr-2" />
          <span>Searching near {userLocation?.city || 'your location'}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {cuisineTypes.map((cuisine) => (
          <button
            key={cuisine.name}
            onClick={() => setSelectedCuisine(cuisine.name)}
            className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
          >
            <div className={`w-16 h-16 mx-auto mb-3 rounded-2xl bg-gradient-to-r ${cuisine.color} flex items-center justify-center text-3xl transform group-hover:scale-110 transition-transform`}>
              {cuisine.emoji}
            </div>
            <h3 className="text-lg font-bold text-white group-hover:text-orange-300 transition-colors">
              {cuisine.name}
            </h3>
          </button>
        ))}
      </div>

      <div className="mt-12 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-6">
        <h3 className="text-white font-semibold mb-3">🌍 Global Cuisine Discovery</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-white/70">
          <div>
            <span className="text-orange-300 font-semibold">🍽️ 24 Cuisines</span>
            <p>From Italian to Ethiopian - explore world flavors</p>
          </div>
          <div>
            <span className="text-blue-300 font-semibold">📍 Real Locations</span>
            <p>Actual restaurants with verified info and ratings</p>
          </div>
          <div>
            <span className="text-green-300 font-semibold">🗺️ Easy Access</span>
            <p>Direct navigation, calls, and website links</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantsPage;